
from flask import Flask, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from config import Config
from models import db

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    # Initialize extensions
    db.init_app(app)
    jwt = JWTManager(app)
    CORS(app)
    
    # Import and register blueprints
    try:
        from auth import auth_bp
        from routes import (
            project_bp, 
            proposal_bp, 
            milestone_bp, 
            message_bp, 
            review_bp, 
            badge_bp, 
            admin_bp
        )
        
        # Register all blueprints
        app.register_blueprint(auth_bp, url_prefix='/api/auth')
        app.register_blueprint(project_bp, url_prefix='/api/projects')
        app.register_blueprint(proposal_bp, url_prefix='/api/proposals')
        app.register_blueprint(milestone_bp, url_prefix='/api/milestones')
        app.register_blueprint(message_bp, url_prefix='/api/messages')
        app.register_blueprint(review_bp, url_prefix='/api/reviews')
        app.register_blueprint(badge_bp, url_prefix='/api/badges')
        app.register_blueprint(admin_bp, url_prefix='/api/admin')
        
        print("✅ All blueprints registered successfully!")
    except Exception as e:
        print(f"❌ Error registering blueprints: {e}")
    
    # Create tables
    with app.app_context():
        try:
            db.create_all()
            print("✅ Database tables created successfully!")
        except Exception as e:
            print(f"❌ Error creating tables: {e}")
    
    # Health check route
    @app.route('/api/health')
    def health_check():
        return jsonify({
            'status': 'healthy', 
            'message': 'SharkTalent API is Functional!',
            'version': '2.0',
            'features': [
                'Authentication',
                'Projects',
                'Proposals (3-limit enforced)',
                'Milestones',
                'Messaging',
                'Reviews',
                'Badges & Quizzes',
                'Admin Panel'
            ]
        })
    
    # API documentation endpoint
    @app.route('/api/endpoints')
    def list_endpoints():
        routes = []
        for rule in app.url_map.iter_rules():
            if rule.endpoint != 'static':
                routes.append({
                    'endpoint': rule.endpoint,
                    'methods': list(rule.methods),
                    'path': str(rule)
                })
        return jsonify({'endpoints': routes})
    
    return app

if __name__ == '__main__':
    app = create_app()
    print("\n🚀 Starting SharkTalent API Server...")
    print("📝 Documentation: http://localhost:5000/api/endpoints")
    print("💚 Health Check: http://localhost:5000/api/health\n")
    app.run(debug=True, port=5000)