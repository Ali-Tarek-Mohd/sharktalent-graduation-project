# Models.py - Enhanced with all SharkTalent features

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import bcrypt

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'user'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'client', 'freelancer', 'admin'
    
    # Enhanced profile fields
    bio = db.Column(db.Text)
    skills = db.Column(db.String(500))  # Comma-separated skills
    portfolio_url = db.Column(db.String(200))
    profile_picture = db.Column(db.String(200))  # URL or filename
    hourly_rate = db.Column(db.Float)  # For freelancers
    
    # Statistics
    total_projects_completed = db.Column(db.Integer, default=0)
    average_rating = db.Column(db.Float, default=0.0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    projects = db.relationship('Project', backref='client', lazy=True, foreign_keys='Project.client_id')
    proposals = db.relationship('Proposal', backref='freelancer', lazy=True, foreign_keys='Proposal.freelancer_id')
    badges = db.relationship('Badge', backref='freelancer', lazy=True)
    sent_messages = db.relationship('Message', foreign_keys='Message.sender_id', backref='sender', lazy=True)
    received_messages = db.relationship('Message', foreign_keys='Message.receiver_id', backref='receiver', lazy=True)
    reviews_given = db.relationship('Review', foreign_keys='Review.reviewer_id', backref='reviewer', lazy=True)
    reviews_received = db.relationship('Review', foreign_keys='Review.reviewee_id', backref='reviewee', lazy=True)
    
    def set_password(self, password):
        self.password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    
    def check_password(self, password):
        return bcrypt.checkpw(password.encode('utf-8'), self.password.encode('utf-8'))
    
    def update_rating(self):
        """Recalculate average rating from all reviews"""
        reviews = Review.query.filter_by(reviewee_id=self.id).all()
        if reviews:
            self.average_rating = sum(r.rating for r in reviews) / len(reviews)
        else:
            self.average_rating = 0.0
        db.session.commit()


class Project(db.Model):
    __tablename__ = 'project'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    budget = db.Column(db.Float, nullable=False)
    skills_required = db.Column(db.String(300))
    status = db.Column(db.String(20), default='open')  # open, in_progress, completed, cancelled
    
    # Enhanced fields
    deadline = db.Column(db.DateTime)
    accepted_proposal_id = db.Column(db.Integer, db.ForeignKey('proposal.id'))
    
    client_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    
    # Relationships
    proposals = db.relationship('Proposal', backref='project', lazy=True, foreign_keys='Proposal.project_id')
    milestones = db.relationship('Milestone', backref='project', lazy=True, cascade='all, delete-orphan')
    messages = db.relationship('Message', backref='project', lazy=True, cascade='all, delete-orphan')
    review = db.relationship('Review', backref='project', uselist=False, cascade='all, delete-orphan')


class Proposal(db.Model):
    __tablename__ = 'proposal'
    
    id = db.Column(db.Integer, primary_key=True)
    cover_letter = db.Column(db.Text, nullable=False)
    bid_amount = db.Column(db.Float, nullable=False)
    timeline_days = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, accepted, rejected, withdrawn
    
    freelancer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    project_id = db.Column(db.Integer, db.ForeignKey('project.id'), nullable=False)
    
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Milestone(db.Model):
    __tablename__ = 'milestone'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('project.id'), nullable=False)
    
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, submitted, approved, rejected
    
    due_date = db.Column(db.DateTime)
    submitted_at = db.Column(db.DateTime)
    approved_at = db.Column(db.DateTime)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Message(db.Model):
    __tablename__ = 'message'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('project.id'), nullable=False)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    content = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Review(db.Model):
    __tablename__ = 'review'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('project.id'), nullable=False)
    reviewer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)  # Client
    reviewee_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)  # Freelancer
    
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    comment = db.Column(db.Text)
    
    # Categories (optional detailed ratings)
    quality_rating = db.Column(db.Integer)  # 1-5
    communication_rating = db.Column(db.Integer)  # 1-5
    deadline_rating = db.Column(db.Integer)  # 1-5
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Badge(db.Model):
    __tablename__ = 'badge'
    
    id = db.Column(db.Integer, primary_key=True)
    freelancer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    skill_name = db.Column(db.String(100), nullable=False)  # e.g., "Python", "React", "UI/UX"
    badge_level = db.Column(db.String(20), default='verified')  # verified, expert, master
    quiz_score = db.Column(db.Integer)  # Score achieved in quiz (0-100)
    
    earned_at = db.Column(db.DateTime, default=datetime.utcnow)


class Quiz(db.Model):
    __tablename__ = 'quiz'
    
    id = db.Column(db.Integer, primary_key=True)
    skill_name = db.Column(db.String(100), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    
    # Store questions as JSON string
    questions = db.Column(db.Text, nullable=False)  # JSON array of questions
    passing_score = db.Column(db.Integer, default=70)  # Minimum score to earn badge
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)


class QuizAttempt(db.Model):
    __tablename__ = 'quiz_attempt'
    
    id = db.Column(db.Integer, primary_key=True)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quiz.id'), nullable=False)
    freelancer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    score = db.Column(db.Integer, nullable=False)
    answers = db.Column(db.Text)  # JSON string of answers
    passed = db.Column(db.Boolean, default=False)
    
    attempted_at = db.Column(db.DateTime, default=datetime.utcnow)