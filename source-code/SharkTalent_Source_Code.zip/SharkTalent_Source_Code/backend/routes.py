from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, User, Project, Proposal, Milestone, Message, Review, Badge, Quiz, QuizAttempt
from datetime import datetime
import json

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def serialize_skills(skills_str):
    """Convert comma-separated string to list"""
    if not skills_str:
        return []
    return [s.strip() for s in str(skills_str).split(',') if s.strip()]

def deserialize_skills(skills):
    """Convert list to comma-separated string"""
    if isinstance(skills, list):
        return ','.join(str(s).strip() for s in skills if s)
    return str(skills).strip() if skills else ''

def parse_date(date_str):
    """Parse date string to datetime object"""
    if not date_str:
        return None
    try:
        return datetime.fromisoformat(date_str.replace('Z', '+00:00'))
    except:
        try:
            return datetime.strptime(date_str, '%Y-%m-%d')
        except:
            return None

def validate_required_fields(data, required_fields):
    """Validate that all required fields are present"""
    missing = [field for field in required_fields if field not in data or not data[field]]
    if missing:
        return False, f"Missing required fields: {', '.join(missing)}"
    return True, None

def get_current_user():
    """Get current authenticated user"""
    user_id = get_jwt_identity()
    return User.query.get(user_id)

def serialize_project(project):
    """Serialize project object to dict"""
    return {
        'id': project.id,
        'title': project.title,
        'description': project.description,
        'budget': project.budget,
        'skills_required': serialize_skills(project.skills_required),
        'status': project.status,
        'deadline': project.deadline.isoformat() if project.deadline else None,
        'client_id': project.client_id,
        'created_at': project.created_at.isoformat(),
        'updated_at': project.updated_at.isoformat() if project.updated_at else None,
        'completed_at': project.completed_at.isoformat() if project.completed_at else None
    }

# ============================================================================
# BLUEPRINTS
# ============================================================================

project_bp = Blueprint('projects', __name__)
proposal_bp = Blueprint('proposals', __name__)
milestone_bp = Blueprint('milestones', __name__)
message_bp = Blueprint('messages', __name__)
review_bp = Blueprint('reviews', __name__)
badge_bp = Blueprint('badges', __name__)
admin_bp = Blueprint('admin', __name__)

# ============================================================================
# PROJECT ROUTES
# ============================================================================

@project_bp.route('/', methods=['GET'])
@jwt_required()
def get_projects():
    """List all projects with optional filtering"""
    try:
        status = request.args.get('status', 'open')
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 10))
        skills = request.args.get('skills')
        
        query = Project.query
        
        if status:
            query = query.filter_by(status=status)
        
        if skills:
            query = query.filter(Project.skills_required.contains(skills))
        
        projects = query.order_by(Project.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        project_list = []
        for project in projects.items:
            proposal_count = Proposal.query.filter_by(project_id=project.id).count()
            project_data = serialize_project(project)
            project_data.update({
                'client_name': f"{project.client.first_name} {project.client.last_name}",
                'client_rating': project.client.average_rating,
                'proposal_count': proposal_count
            })
            project_list.append(project_data)
        
        return jsonify({
            'projects': project_list,
            'total': projects.total,
            'pages': projects.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        print(f"Error listing projects: {str(e)}")
        return jsonify({'message': 'Failed to fetch projects'}), 500

@project_bp.route('/<int:project_id>', methods=['GET'])
@jwt_required()
def get_project(project_id):
    """Get single project by ID"""
    try:
        project = Project.query.get(project_id)
        if not project:
            return jsonify({'message': 'Project not found'}), 404
        
        project_data = serialize_project(project)
        project_data.update({
            'client_name': f"{project.client.first_name} {project.client.last_name}",
            'client_rating': project.client.average_rating
        })
        
        return jsonify(project_data), 200
        
    except Exception as e:
        print(f"Error fetching project: {str(e)}")
        return jsonify({'message': 'Failed to fetch project'}), 500

@project_bp.route('/', methods=['POST'])
@jwt_required()
def create_project():
    """Create a new project (clients only)"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        if user.role != 'client':
            return jsonify({'message': 'Only clients can create projects'}), 403
        
        data = request.get_json()
        
        # Validate required fields
        valid, error = validate_required_fields(data, ['title', 'description', 'budget'])
        if not valid:
            return jsonify({'message': error}), 400
        
        # Parse deadline FIRST (before using it)
        deadline = parse_date(data.get('deadline'))
        
        # Convert skills to string
        skills_str = deserialize_skills(data.get('skills_required', []))
        
        # Validate budget
        try:
            budget = float(data['budget'])
            if budget <= 0:
                return jsonify({'message': 'Budget must be greater than 0'}), 400
        except (ValueError, TypeError):
            return jsonify({'message': 'Invalid budget value'}), 400
        
        # Create project
        new_project = Project(
            title=data['title'].strip(),
            description=data['description'].strip(),
            budget=budget,
            skills_required=skills_str,
            deadline=deadline,
            client_id=user.id
        )
        
        db.session.add(new_project)
        db.session.commit()
        
        return jsonify({
            'message': 'Project created successfully',
            'project': serialize_project(new_project)
        }), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"Error creating project: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'message': 'Failed to create project'}), 500

@project_bp.route('/<int:project_id>', methods=['PUT'])
@jwt_required()
def update_project(project_id):
    """Update a project (owner or admin only)"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        project = Project.query.get(project_id)
        if not project:
            return jsonify({'message': 'Project not found'}), 404
        
        # Check ownership or admin
        if project.client_id != user.id and user.role != 'admin':
            return jsonify({'message': 'Access denied'}), 403
        
        data = request.get_json()
        
        # Update fields
        if 'title' in data and data['title']:
            project.title = data['title'].strip()
        
        if 'description' in data and data['description']:
            project.description = data['description'].strip()
        
        if 'budget' in data:
            try:
                budget = float(data['budget'])
                if budget > 0:
                    project.budget = budget
            except (ValueError, TypeError):
                return jsonify({'message': 'Invalid budget value'}), 400
        
        if 'skills_required' in data:
            project.skills_required = deserialize_skills(data['skills_required'])
        
        if 'status' in data and data['status'] in ['open', 'in_progress', 'completed', 'cancelled']:
            project.status = data['status']
        
        if 'deadline' in data:
            project.deadline = parse_date(data['deadline'])
        
        project.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Project updated successfully',
            'project': serialize_project(project)
        }), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"Error updating project: {str(e)}")
        return jsonify({'message': 'Failed to update project'}), 500

@project_bp.route('/<int:project_id>', methods=['DELETE'])
@jwt_required()
def delete_project(project_id):
    """Delete a project (owner or admin only)"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        project = Project.query.get(project_id)
        if not project:
            return jsonify({'message': 'Project not found'}), 404
        
        # Check ownership or admin
        if project.client_id != user.id and user.role != 'admin':
            return jsonify({'message': 'Access denied'}), 403
        
        db.session.delete(project)
        db.session.commit()
        
        return jsonify({'message': 'Project deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"Error deleting project: {str(e)}")
        return jsonify({'message': 'Failed to delete project'}), 500

@project_bp.route('/my-projects', methods=['GET'])
@jwt_required()
def get_my_projects():
    """Get all projects for current user (clients only)"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        if user.role != 'client':
            return jsonify({'message': 'Only clients have projects'}), 403
        
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 10))
        
        projects = Project.query.filter_by(client_id=user.id).order_by(
            Project.created_at.desc()
        ).paginate(page=page, per_page=per_page, error_out=False)
        
        project_list = []
        for project in projects.items:
            proposal_count = Proposal.query.filter_by(project_id=project.id).count()
            project_data = serialize_project(project)
            project_data['proposal_count'] = proposal_count
            project_list.append(project_data)
        
        return jsonify({
            'projects': project_list,
            'total': projects.total,
            'pages': projects.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        print(f"Error fetching user projects: {str(e)}")
        return jsonify({'message': 'Failed to fetch projects'}), 500

# ============================================================================
# PROPOSAL ROUTES
# ============================================================================

@proposal_bp.route('/', methods=['POST'])
@jwt_required()
def create_proposal():
    """Submit a proposal (freelancers only, max 3 pending)"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        if user.role != 'freelancer':
            return jsonify({'message': 'Only freelancers can submit proposals'}), 403
        
        data = request.get_json()
        
        # Validate required fields
        valid, error = validate_required_fields(
            data, ['project_id', 'cover_letter', 'bid_amount', 'timeline_days']
        )
        if not valid:
            return jsonify({'message': error}), 400
        
        # Check if project exists and is open
        project = Project.query.get(data['project_id'])
        if not project:
            return jsonify({'message': 'Project not found'}), 404
        
        if project.status != 'open':
            return jsonify({'message': 'Project is not open for proposals'}), 400
        
        # Check for duplicate proposal
        existing = Proposal.query.filter_by(
            project_id=data['project_id'],
            freelancer_id=user.id
        ).first()
        
        if existing:
            return jsonify({'message': 'You have already submitted a proposal for this project'}), 400
        
        # CRITICAL: Check 3-proposal limit
        pending_count = Proposal.query.filter_by(
            freelancer_id=user.id,
            status='pending'
        ).count()
        
        if pending_count >= 3:
            return jsonify({
                'message': 'You have reached the maximum of 3 pending proposals. '
                          'Please wait for responses before submitting more.'
            }), 400
        
        # Validate bid amount and timeline
        try:
            bid_amount = float(data['bid_amount'])
            timeline_days = int(data['timeline_days'])
            
            if bid_amount <= 0 or timeline_days <= 0:
                return jsonify({'message': 'Bid amount and timeline must be positive'}), 400
        except (ValueError, TypeError):
            return jsonify({'message': 'Invalid bid amount or timeline'}), 400
        
        # Create proposal
        proposal = Proposal(
            project_id=data['project_id'],
            freelancer_id=user.id,
            cover_letter=data['cover_letter'].strip(),
            bid_amount=bid_amount,
            timeline_days=timeline_days
        )
        
        db.session.add(proposal)
        db.session.commit()
        
        return jsonify({
            'message': 'Proposal submitted successfully',
            'proposal': {
                'id': proposal.id,
                'project_id': proposal.project_id,
                'status': proposal.status,
                'submitted_at': proposal.submitted_at.isoformat()
            },
            'remaining_slots': 2 - pending_count
        }), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"Error creating proposal: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'message': 'Failed to submit proposal'}), 500

@proposal_bp.route('/project/<int:project_id>', methods=['GET'])
@jwt_required()
def get_project_proposals(project_id):
    """Get all proposals for a project (project owner only)"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        project = Project.query.get(project_id)
        if not project:
            return jsonify({'message': 'Project not found'}), 404
        
        # Only project owner can see proposals
        if project.client_id != user.id:
            return jsonify({'message': 'You can only view proposals for your own projects'}), 403
        
        proposals = Proposal.query.filter_by(project_id=project_id).order_by(
            Proposal.submitted_at.desc()
        ).all()
        
        # Include freelancer info
        result = []
        for p in proposals:
            freelancer = User.query.get(p.freelancer_id)
            proposal_data = {
                'id': p.id,
                'cover_letter': p.cover_letter,
                'bid_amount': p.bid_amount,
                'timeline_days': p.timeline_days,
                'status': p.status,
                'submitted_at': p.submitted_at.isoformat()
            }
            if freelancer:
                proposal_data['freelancer'] = {
                    'id': freelancer.id,
                    'name': f"{freelancer.first_name} {freelancer.last_name}",
                    'average_rating': freelancer.average_rating,
                    'total_projects_completed': freelancer.total_projects_completed,
                    'skills': freelancer.skills
                }
            result.append(proposal_data)
        
        return jsonify({'proposals': result}), 200
        
    except Exception as e:
        print(f"Error fetching proposals: {str(e)}")
        return jsonify({'message': 'Failed to fetch proposals'}), 500

@proposal_bp.route('/my-proposals', methods=['GET'])
@jwt_required()
def get_my_proposals():
    """Get all proposals for current freelancer"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        if user.role != 'freelancer':
            return jsonify({'message': 'Only freelancers have proposals'}), 403
        
        proposals = Proposal.query.filter_by(freelancer_id=user.id).order_by(
            Proposal.submitted_at.desc()
        ).all()
        
        # Include project info
        result = []
        for p in proposals:
            project = Project.query.get(p.project_id)
            proposal_data = {
                'id': p.id,
                'cover_letter': p.cover_letter,
                'bid_amount': p.bid_amount,
                'timeline_days': p.timeline_days,
                'status': p.status,
                'submitted_at': p.submitted_at.isoformat()
            }
            if project:
                proposal_data['project'] = {
                    'id': project.id,
                    'title': project.title,
                    'budget': project.budget,
                    'status': project.status
                }
            result.append(proposal_data)
        
        # Include pending count
        pending_count = sum(1 for p in proposals if p.status == 'pending')
        
        return jsonify({
            'proposals': result,
            'pending_count': pending_count,
            'remaining_slots': max(0, 3 - pending_count)
        }), 200
        
    except Exception as e:
        print(f"Error fetching proposals: {str(e)}")
        return jsonify({'message': 'Failed to fetch proposals'}), 500

@proposal_bp.route('/<int:proposal_id>/status', methods=['PUT'])
@jwt_required()
def update_proposal_status(proposal_id):
    """Accept or reject a proposal (project owner only)"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        proposal = Proposal.query.get(proposal_id)
        if not proposal:
            return jsonify({'message': 'Proposal not found'}), 404
        
        project = Project.query.get(proposal.project_id)
        if not project:
            return jsonify({'message': 'Project not found'}), 404
        
        # Only project owner can update
        if project.client_id != user.id:
            return jsonify({'message': 'Only project owner can update proposal status'}), 403
        
        data = request.get_json()
        status = data.get('status')
        
        if status not in ['accepted', 'rejected']:
            return jsonify({'message': 'Status must be "accepted" or "rejected"'}), 400
        
        proposal.status = status
        proposal.updated_at = datetime.utcnow()
        
        # If accepted, update project and reject other proposals
        if status == 'accepted':
            project.status = 'in_progress'
            project.accepted_proposal_id = proposal.id
            
            # Reject all other pending proposals
            other_proposals = Proposal.query.filter(
                Proposal.project_id == project.id,
                Proposal.id != proposal.id,
                Proposal.status == 'pending'
            ).all()
            
            for other in other_proposals:
                other.status = 'rejected'
                other.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'message': f'Proposal {status} successfully',
            'proposal': {
                'id': proposal.id,
                'status': proposal.status
            }
        }), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"Error updating proposal: {str(e)}")
        return jsonify({'message': 'Failed to update proposal'}), 500

@proposal_bp.route('/<int:proposal_id>', methods=['DELETE'])
@jwt_required()
def delete_proposal(proposal_id):
    """Withdraw a proposal (proposal owner only)"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        proposal = Proposal.query.get(proposal_id)
        if not proposal:
            return jsonify({'message': 'Proposal not found'}), 404
        
        # Only proposal owner can delete
        if proposal.freelancer_id != user.id:
            return jsonify({'message': 'You can only withdraw your own proposals'}), 403
        
        if proposal.status != 'pending':
            return jsonify({'message': 'Can only withdraw pending proposals'}), 400
        
        db.session.delete(proposal)
        db.session.commit()
        
        return jsonify({'message': 'Proposal withdrawn successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"Error deleting proposal: {str(e)}")
        return jsonify({'message': 'Failed to withdraw proposal'}), 500

# ============================================================================
# MILESTONE ROUTES  
# ============================================================================

@milestone_bp.route('/', methods=['POST'])
@jwt_required()
def create_milestone():
    """Create a milestone for a project"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        data = request.get_json()
        
        # Validate required fields
        valid, error = validate_required_fields(
            data, ['project_id', 'title', 'amount']
        )
        if not valid:
            return jsonify({'message': error}), 400
        
        # Check project exists
        project = Project.query.get(data['project_id'])
        if not project:
            return jsonify({'message': 'Project not found'}), 404
        
        # Only project owner can create milestones
        if project.client_id != user.id:
            return jsonify({'message': 'Only project owner can create milestones'}), 403
        
        # Validate amount
        try:
            amount = float(data['amount'])
            if amount <= 0:
                return jsonify({'message': 'Amount must be positive'}), 400
        except (ValueError, TypeError):
            return jsonify({'message': 'Invalid amount'}), 400
        
        # Parse due date
        due_date = parse_date(data.get('due_date'))
        
        # Create milestone
        milestone = Milestone(
            project_id=data['project_id'],
            title=data['title'].strip(),
            description=data.get('description', '').strip(),
            amount=amount,
            due_date=due_date
        )
        
        db.session.add(milestone)
        db.session.commit()
        
        return jsonify({
            'message': 'Milestone created successfully',
            'milestone': {
                'id': milestone.id,
                'title': milestone.title,
                'amount': milestone.amount,
                'status': milestone.status
            }
        }), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"Error creating milestone: {str(e)}")
        return jsonify({'message': 'Failed to create milestone'}), 500

@milestone_bp.route('/project/<int:project_id>', methods=['GET'])
@jwt_required()
def get_project_milestones(project_id):
    """Get all milestones for a project"""
    try:
        project = Project.query.get(project_id)
        if not project:
            return jsonify({'message': 'Project not found'}), 404
        
        milestones = Milestone.query.filter_by(project_id=project_id).order_by(
            Milestone.created_at.asc()
        ).all()
        
        result = []
        for m in milestones:
            result.append({
                'id': m.id,
                'title': m.title,
                'description': m.description,
                'amount': m.amount,
                'status': m.status,
                'due_date': m.due_date.isoformat() if m.due_date else None,
                'submitted_at': m.submitted_at.isoformat() if m.submitted_at else None,
                'approved_at': m.approved_at.isoformat() if m.approved_at else None,
                'created_at': m.created_at.isoformat()
            })
        
        return jsonify({'milestones': result}), 200
        
    except Exception as e:
        print(f"Error fetching milestones: {str(e)}")
        return jsonify({'message': 'Failed to fetch milestones'}), 500
    
@milestone_bp.route('/<int:milestone_id>/status', methods=['PUT'])
@jwt_required()
def update_milestone_status(milestone_id):
    """Update milestone status with auto-completion check"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        milestone = Milestone.query.get(milestone_id)
        if not milestone:
            return jsonify({'message': 'Milestone not found'}), 404
        
        project = Project.query.get(milestone.project_id)
        if not project:
            return jsonify({'message': 'Project not found'}), 404
        
        data = request.get_json()
        status = data.get('status')
        
        if status not in ['pending', 'submitted', 'approved', 'rejected']:
            return jsonify({'message': 'Invalid status'}), 400
        
        # Update based on role
        if status == 'submitted':
            # Freelancer submits milestone
            if user.role != 'freelancer':
                return jsonify({'message': 'Only freelancers can submit milestones'}), 403
            milestone.status = 'submitted'
            milestone.submitted_at = datetime.utcnow()
            
        elif status in ['approved', 'rejected']:
            # Client approves/rejects milestone
            if project.client_id != user.id:
                return jsonify({'message': 'Only project owner can approve/reject'}), 403
            milestone.status = status
            if status == 'approved':
                milestone.approved_at = datetime.utcnow()
        
        milestone.updated_at = datetime.utcnow()
        db.session.commit()

        if status == 'approved':
            check_and_complete_project(project.id)
        
        return jsonify({
            'message': f'Milestone {status} successfully',
            'milestone': {
                'id': milestone.id,
                'status': milestone.status
            }
        }), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"Error updating milestone: {str(e)}")
        return jsonify({'message': 'Failed to update milestone'}), 500

def check_and_complete_project(project_id):
    """Check if all milestones are approved and auto-complete project"""
    try:
        project = Project.query.get(project_id)
        if not project or project.status != 'in_progress':
            return
        
        # Get all milestones for this project
        milestones = Milestone.query.filter_by(project_id=project_id).all()
        
        if not milestones:
            return
        
        # Check if ALL milestones are approved
        all_approved = all(m.status == 'approved' for m in milestones)
        
        if all_approved:
            # 🎉 All milestones approved! Complete the project
            project.status = 'completed'
            project.completed_at = datetime.utcnow()
            db.session.commit()
            
            print(f"🎉 Project {project.id} '{project.title}' auto-completed! All {len(milestones)} milestones approved.")
    
    except Exception as e:
        print(f"Error in check_and_complete_project: {str(e)}")
        db.session.rollback()

@milestone_bp.route('/<int:milestone_id>', methods=['DELETE'])
@jwt_required()
def delete_milestone(milestone_id):
    """Delete a milestone (project owner only)"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        milestone = Milestone.query.get(milestone_id)
        if not milestone:
            return jsonify({'message': 'Milestone not found'}), 404
        
        project = Project.query.get(milestone.project_id)
        if not project:
            return jsonify({'message': 'Project not found'}), 404
        
        # Only project owner can delete
        if project.client_id != user.id:
            return jsonify({'message': 'Only project owner can delete milestones'}), 403
        
        db.session.delete(milestone)
        db.session.commit()
        
        return jsonify({'message': 'Milestone deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"Error deleting milestone: {str(e)}")
        return jsonify({'message': 'Failed to delete milestone'}), 500

# ============================================================================
# MESSAGE ROUTES
# ============================================================================

@message_bp.route('/', methods=['POST'])
@jwt_required()
def send_message():
    """Send a message"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        data = request.get_json()
        
        # Validate required fields
        valid, error = validate_required_fields(
            data, ['project_id', 'receiver_id', 'content']
        )
        if not valid:
            return jsonify({'message': error}), 400
        
        # Check project exists
        project = Project.query.get(data['project_id'])
        if not project:
            return jsonify({'message': 'Project not found'}), 404
        
        # Check receiver exists
        receiver = User.query.get(data['receiver_id'])
        if not receiver:
            return jsonify({'message': 'Receiver not found'}), 404
        
        # Validate user can message on this project
        if user.id not in [project.client_id, data['receiver_id']]:
            # Check if user is freelancer on project
            proposal = Proposal.query.filter_by(
                project_id=data['project_id'],
                freelancer_id=user.id
            ).first()
            if not proposal:
                return jsonify({'message': 'You can only message on projects you are involved in'}), 403
        
        # Create message
        message = Message(
            project_id=data['project_id'],
            sender_id=user.id,
            receiver_id=data['receiver_id'],
            content=data['content'].strip()
        )
        
        db.session.add(message)
        db.session.commit()
        
        return jsonify({
            'message': 'Message sent successfully',
            'id': message.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"Error sending message: {str(e)}")
        return jsonify({'message': 'Failed to send message'}), 500

@message_bp.route('/project/<int:project_id>', methods=['GET'])
@jwt_required()
def get_project_messages(project_id):
    """Get all messages for a project"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        project = Project.query.get(project_id)
        if not project:
            return jsonify({'message': 'Project not found'}), 404
        
        # Get messages where user is sender or receiver
        messages = Message.query.filter(
            Message.project_id == project_id,
            db.or_(Message.sender_id == user.id, Message.receiver_id == user.id)
        ).order_by(Message.created_at.asc()).all()
        
        result = []
        for m in messages:
            sender = User.query.get(m.sender_id)
            receiver = User.query.get(m.receiver_id)
            result.append({
                'id': m.id,
                'content': m.content,
                'is_read': m.is_read,
                'created_at': m.created_at.isoformat(),
                'sender': {
                    'id': sender.id,
                    'name': f"{sender.first_name} {sender.last_name}"
                } if sender else None,
                'receiver': {
                    'id': receiver.id,
                    'name': f"{receiver.first_name} {receiver.last_name}"
                } if receiver else None
            })
        
        return jsonify({'messages': result}), 200
        
    except Exception as e:
        print(f"Error fetching messages: {str(e)}")
        return jsonify({'message': 'Failed to fetch messages'}), 500

@message_bp.route('/<int:message_id>/read', methods=['PUT'])
@jwt_required()
def mark_message_read(message_id):
    """Mark a message as read"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        message = Message.query.get(message_id)
        if not message:
            return jsonify({'message': 'Message not found'}), 404
        
        # Only receiver can mark as read
        if message.receiver_id != user.id:
            return jsonify({'message': 'Only receiver can mark message as read'}), 403
        
        message.is_read = True
        db.session.commit()
        
        return jsonify({'message': 'Message marked as read'}), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"Error marking message: {str(e)}")
        return jsonify({'message': 'Failed to mark message'}), 500

# ============================================================================
# REVIEW ROUTES
# ============================================================================

@review_bp.route('/', methods=['POST'])
@jwt_required()
def create_review():
    """Create a review (client reviews freelancer after project completion)"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        if user.role != 'client':
            return jsonify({'message': 'Only clients can create reviews'}), 403
        
        data = request.get_json()
        
        # Validate required fields
        valid, error = validate_required_fields(
            data, ['project_id', 'reviewee_id', 'rating']
        )
        if not valid:
            return jsonify({'message': error}), 400
        
        # Check project exists and is completed
        project = Project.query.get(data['project_id'])
        if not project:
            return jsonify({'message': 'Project not found'}), 404
        
        if project.status != 'completed':
            return jsonify({'message': 'Can only review completed projects'}), 400
        
        if project.client_id != user.id:
            return jsonify({'message': 'Only project owner can review'}), 403
        
        # Check if review already exists
        existing = Review.query.filter_by(project_id=data['project_id']).first()
        if existing:
            return jsonify({'message': 'Review already exists for this project'}), 400
        
        # Validate rating
        try:
            rating = int(data['rating'])
            if rating < 1 or rating > 5:
                return jsonify({'message': 'Rating must be between 1 and 5'}), 400
        except (ValueError, TypeError):
            return jsonify({'message': 'Invalid rating'}), 400
        
        # Create review
        review = Review(
            project_id=data['project_id'],
            reviewer_id=user.id,
            reviewee_id=data['reviewee_id'],
            rating=rating,
            comment=data.get('comment', '').strip(),
            quality_rating=data.get('quality_rating'),
            communication_rating=data.get('communication_rating'),
            deadline_rating=data.get('deadline_rating')
        )
        
        db.session.add(review)
        db.session.commit()
        
        # Update freelancer's average rating
        freelancer = User.query.get(data['reviewee_id'])
        if freelancer:
            freelancer.update_rating()
        
        return jsonify({
            'message': 'Review created successfully',
            'review': {
                'id': review.id,
                'rating': review.rating
            }
        }), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"Error creating review: {str(e)}")
        return jsonify({'message': 'Failed to create review'}), 500

@review_bp.route('/user/<int:user_id>', methods=['GET'])
@jwt_required()
def get_user_reviews(user_id):
    """Get all reviews for a user (freelancer)"""
    try:
        reviews = Review.query.filter_by(reviewee_id=user_id).order_by(
            Review.created_at.desc()
        ).all()
        
        result = []
        for r in reviews:
            reviewer = User.query.get(r.reviewer_id)
            project = Project.query.get(r.project_id)
            result.append({
                'id': r.id,
                'rating': r.rating,
                'comment': r.comment,
                'quality_rating': r.quality_rating,
                'communication_rating': r.communication_rating,
                'deadline_rating': r.deadline_rating,
                'created_at': r.created_at.isoformat(),
                'reviewer': {
                    'name': f"{reviewer.first_name} {reviewer.last_name}"
                } if reviewer else None,
                'project': {
                    'title': project.title
                } if project else None
            })
        
        return jsonify({'reviews': result}), 200
        
    except Exception as e:
        print(f"Error fetching reviews: {str(e)}")
        return jsonify({'message': 'Failed to fetch reviews'}), 500

@review_bp.route('/project/<int:project_id>', methods=['GET'])
@jwt_required()
def get_project_review(project_id):
    """Get review for a specific project"""
    try:
        review = Review.query.filter_by(project_id=project_id).first()
        
        if not review:
            return jsonify({'message': 'No review found for this project'}), 404
        
        reviewer = User.query.get(review.reviewer_id)
        reviewee = User.query.get(review.reviewee_id)
        
        return jsonify({
            'id': review.id,
            'rating': review.rating,
            'comment': review.comment,
            'quality_rating': review.quality_rating,
            'communication_rating': review.communication_rating,
            'deadline_rating': review.deadline_rating,
            'created_at': review.created_at.isoformat(),
            'reviewer': {
                'id': reviewer.id,
                'name': f"{reviewer.first_name} {reviewer.last_name}"
            } if reviewer else None,
            'reviewee': {
                'id': reviewee.id,
                'name': f"{reviewee.first_name} {reviewee.last_name}"
            } if reviewee else None
        }), 200
        
    except Exception as e:
        print(f"Error fetching review: {str(e)}")
        return jsonify({'message': 'Failed to fetch review'}), 500


@review_bp.route('/by-reviewer/<int:reviewer_id>', methods=['GET'])
@jwt_required()
def get_reviews_by_reviewer(reviewer_id):
    """Get all reviews written by a specific reviewer (client)"""
    try:
        reviews = Review.query.filter_by(reviewer_id=reviewer_id).order_by(
            Review.created_at.desc()
        ).all()
        
        result = []
        for r in reviews:
            reviewee = User.query.get(r.reviewee_id)
            project = Project.query.get(r.project_id)
            result.append({
                'id': r.id,
                'rating': r.rating,
                'comment': r.comment,
                'quality_rating': r.quality_rating,
                'communication_rating': r.communication_rating,
                'deadline_rating': r.deadline_rating,
                'created_at': r.created_at.isoformat(),
                'reviewee': {
                    'id': reviewee.id if reviewee else None,
                    'name': f"{reviewee.first_name} {reviewee.last_name}"
                } if reviewee else None,
                'project': {
                    'id': project.id if project else None,
                    'title': project.title
                } if project else None
            })
        
        return jsonify({'reviews': result}), 200
        
    except Exception as e:
        print(f"Error fetching reviews by reviewer: {str(e)}")
        return jsonify({'message': 'Failed to fetch reviews'}), 500

# ============================================================================
# BADGE & QUIZ ROUTES
# ============================================================================

@badge_bp.route('/quizzes', methods=['GET'])
@jwt_required()
def get_quizzes():
    """Get all active quizzes"""
    try:
        quizzes = Quiz.query.filter_by(is_active=True).order_by(
            Quiz.skill_name.asc()
        ).all()
        
        result = []
        for q in quizzes:
            result.append({
                'id': q.id,
                'skill_name': q.skill_name,
                'title': q.title,
                'description': q.description,
                'passing_score': q.passing_score
            })
        
        return jsonify({'quizzes': result}), 200
        
    except Exception as e:
        print(f"Error fetching quizzes: {str(e)}")
        return jsonify({'message': 'Failed to fetch quizzes'}), 500

@badge_bp.route('/quiz/<int:quiz_id>', methods=['GET'])
@jwt_required()
def get_quiz(quiz_id):
    """Get quiz details with questions"""
    try:
        quiz = Quiz.query.get(quiz_id)
        if not quiz or not quiz.is_active:
            return jsonify({'message': 'Quiz not found'}), 404
        
        questions = json.loads(quiz.questions)
        
        # Remove correct answers from questions
        safe_questions = []
        for q in questions:
            safe_q = {
                'question': q['question'],
                'options': q['options']
            }
            safe_questions.append(safe_q)
        
        return jsonify({
            'id': quiz.id,
            'skill_name': quiz.skill_name,
            'title': quiz.title,
            'description': quiz.description,
            'passing_score': quiz.passing_score,
            'questions': safe_questions
        }), 200
        
    except Exception as e:
        print(f"Error fetching quiz: {str(e)}")
        return jsonify({'message': 'Failed to fetch quiz'}), 500

@badge_bp.route('/attempt', methods=['POST'])
@jwt_required()
def submit_quiz_attempt():
    """Submit quiz attempt and earn badge if passed"""
    try:
        user = get_current_user()
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        if user.role != 'freelancer':
            return jsonify({'message': 'Only freelancers can take quizzes'}), 403
        
        data = request.get_json()
        
        # Validate required fields
        valid, error = validate_required_fields(data, ['quiz_id', 'answers'])
        if not valid:
            return jsonify({'message': error}), 400
        
        quiz = Quiz.query.get(data['quiz_id'])
        if not quiz or not quiz.is_active:
            return jsonify({'message': 'Quiz not found'}), 404
        
        # Calculate score
        questions = json.loads(quiz.questions)
        user_answers = data['answers']
        correct_count = 0
        
        for i, question in enumerate(questions):
            if str(i) in user_answers and user_answers[str(i)] == question.get('correct_answer'):
                correct_count += 1
        
        score = int((correct_count / len(questions)) * 100) if questions else 0
        passed = score >= quiz.passing_score
        
        # Record attempt
        attempt = QuizAttempt(
            quiz_id=data['quiz_id'],
            freelancer_id=user.id,
            score=score,
            answers=json.dumps(user_answers),
            passed=passed
        )
        
        db.session.add(attempt)
        
        # Award badge if passed and not already earned
        badge_earned = False
        if passed:
            existing_badge = Badge.query.filter_by(
                freelancer_id=user.id,
                skill_name=quiz.skill_name
            ).first()
            
            if not existing_badge:
                badge = Badge(
                    freelancer_id=user.id,
                    skill_name=quiz.skill_name,
                    quiz_score=score
                )
                db.session.add(badge)
                badge_earned = True
        
        db.session.commit()
        
        return jsonify({
            'message': 'Quiz completed',
            'score': score,
            'passed': passed,
            'badge_earned': badge_earned,
            'correct_answers': correct_count,
            'total_questions': len(questions)
        }), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"Error submitting quiz: {str(e)}")
        return jsonify({'message': 'Failed to submit quiz'}), 500

@badge_bp.route('/user/<int:user_id>', methods=['GET'])
@jwt_required()
def get_user_badges(user_id):
    """Get all badges for a user"""
    try:
        badges = Badge.query.filter_by(freelancer_id=user_id).order_by(
            Badge.earned_at.desc()
        ).all()
        
        result = []
        for b in badges:
            result.append({
                'id': b.id,
                'skill_name': b.skill_name,
                'badge_level': b.badge_level,
                'quiz_score': b.quiz_score,
                'earned_at': b.earned_at.isoformat()
            })
        
        return jsonify({'badges': result}), 200
        
    except Exception as e:
        print(f"Error fetching badges: {str(e)}")
        return jsonify({'message': 'Failed to fetch badges'}), 500

# ============================================================================
# ADMIN ROUTES
# ============================================================================

@admin_bp.route('/users', methods=['GET'])
@jwt_required()
def get_all_users():
    """Get all users (admin only)"""
    try:
        user = get_current_user()
        if not user or user.role != 'admin':
            return jsonify({'message': 'Admin access required'}), 403
        
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))
        role_filter = request.args.get('role')
        
        query = User.query
        
        if role_filter:
            query = query.filter_by(role=role_filter)
        
        users = query.order_by(User.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        user_list = []
        for u in users.items:
            user_list.append({
                'id': u.id,
                'email': u.email,
                'first_name': u.first_name,
                'last_name': u.last_name,
                'role': u.role,
                'created_at': u.created_at.isoformat(),
                'total_projects_completed': u.total_projects_completed,
                'average_rating': u.average_rating
            })
        
        return jsonify({
            'users': user_list,
            'total': users.total,
            'pages': users.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        print(f"Error fetching users: {str(e)}")
        return jsonify({'message': 'Failed to fetch users'}), 500

@admin_bp.route('/users/<int:user_id>/role', methods=['PUT'])
@jwt_required()
def update_user_role(user_id):
    """Update user role (admin only)"""
    try:
        admin = get_current_user()
        if not admin or admin.role != 'admin':
            return jsonify({'message': 'Admin access required'}), 403
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        data = request.get_json()
        new_role = data.get('role')
        
        if new_role not in ['client', 'freelancer', 'admin']:
            return jsonify({'message': 'Invalid role'}), 400
        
        # Prevent removing last admin
        if user.role == 'admin' and new_role != 'admin':
            admin_count = User.query.filter_by(role='admin').count()
            if admin_count <= 1:
                return jsonify({'message': 'Cannot remove the last admin'}), 400
        
        user.role = new_role
        db.session.commit()
        
        return jsonify({
            'message': 'User role updated successfully',
            'user': {
                'id': user.id,
                'role': user.role
            }
        }), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"Error updating user role: {str(e)}")
        return jsonify({'message': 'Failed to update user role'}), 500

@admin_bp.route('/users/<int:user_id>', methods=['DELETE'])
@jwt_required()
def delete_user(user_id):
    """Delete a user (admin only)"""
    try:
        admin = get_current_user()
        if not admin or admin.role != 'admin':
            return jsonify({'message': 'Admin access required'}), 403
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        # Prevent deleting yourself
        if user.id == admin.id:
            return jsonify({'message': 'Cannot delete your own account'}), 400
        
        # Prevent deleting last admin
        if user.role == 'admin':
            admin_count = User.query.filter_by(role='admin').count()
            if admin_count <= 1:
                return jsonify({'message': 'Cannot delete the last admin'}), 400
        
        db.session.delete(user)
        db.session.commit()
        
        return jsonify({'message': 'User deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"Error deleting user: {str(e)}")
        return jsonify({'message': 'Failed to delete user'}), 500

@admin_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_platform_stats():
    """Get platform statistics (admin only)"""
    try:
        admin = get_current_user()
        if not admin or admin.role != 'admin':
            return jsonify({'message': 'Admin access required'}), 403
        
        total_users = User.query.count()
        total_clients = User.query.filter_by(role='client').count()
        total_freelancers = User.query.filter_by(role='freelancer').count()
        total_projects = Project.query.count()
        open_projects = Project.query.filter_by(status='open').count()
        in_progress_projects = Project.query.filter_by(status='in_progress').count()
        completed_projects = Project.query.filter_by(status='completed').count()
        total_proposals = Proposal.query.count()
        total_reviews = Review.query.count()
        total_badges = Badge.query.count()
        
        return jsonify({
            'users': {
                'total': total_users,
                'clients': total_clients,
                'freelancers': total_freelancers
            },
            'projects': {
                'total': total_projects,
                'open': open_projects,
                'in_progress': in_progress_projects,
                'completed': completed_projects
            },
            'proposals': total_proposals,
            'reviews': total_reviews,
            'badges': total_badges
        }), 200
        
    except Exception as e:
        print(f"Error fetching stats: {str(e)}")
        return jsonify({'message': 'Failed to fetch statistics'}), 500
    
    # ============================================
# USER PROFILE ROUTES
# Replace the @app.route sections at the end of routes.py with this
# ============================================

@admin_bp.route('/users/<int:user_id>/profile', methods=['GET'])
def get_user_profile(user_id):
    """Get detailed user profile with stats, reviews, and badges"""
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        # Get user's reviews
        reviews = Review.query.filter_by(reviewee_id=user_id).order_by(
            Review.created_at.desc()
        ).limit(10).all()
        
        reviews_data = []
        for review in reviews:
            reviewer = User.query.get(review.reviewer_id)
            project = Project.query.get(review.project_id)
            reviews_data.append({
                'id': review.id,
                'rating': review.rating,
                'comment': review.comment,
                'quality_rating': review.quality_rating,
                'communication_rating': review.communication_rating,
                'deadline_rating': review.deadline_rating,
                'created_at': review.created_at.isoformat() if review.created_at else None,
                'reviewer': {
                    'id': reviewer.id,
                    'name': f"{reviewer.first_name} {reviewer.last_name}",
                    'profile_picture': reviewer.profile_picture
                },
                'project': {
                    'id': project.id,
                    'title': project.title
                } if project else None
            })
        
        # Get user's badges (if freelancer)
        badges_data = []
        if user.role == 'freelancer':
            badges = Badge.query.filter_by(freelancer_id=user_id).order_by(
                Badge.earned_at.desc()
            ).all()
            
            for badge in badges:
                badges_data.append({
                    'id': badge.id,
                    'skill_name': badge.skill_name,
                    'badge_level': badge.badge_level,
                    'quiz_score': badge.quiz_score,
                    'earned_at': badge.earned_at.isoformat() if badge.earned_at else None
                })
        
        # Get completed projects count
        if user.role == 'freelancer':
            accepted_proposals = Proposal.query.filter_by(
                freelancer_id=user_id,
                status='accepted'
            ).all()
            
            completed_projects = 0
            for proposal in accepted_proposals:
                project = Project.query.get(proposal.project_id)
                if project and project.status == 'completed':
                    completed_projects += 1
            
            projects_count = completed_projects
        else:
            projects_count = Project.query.filter_by(
                client_id=user_id,
                status='completed'
            ).count()
        
        # Parse skills
        skills_list = []
        if user.skills:
            skills_list = [s.strip() for s in user.skills.split(',') if s.strip()]
        
        profile_data = {
            'id': user.id,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'email': user.email,
            'role': user.role,
            'bio': user.bio,
            'skills': skills_list,
            'portfolio_url': user.portfolio_url,
            'profile_picture': user.profile_picture,
            'hourly_rate': user.hourly_rate,
            'average_rating': round(user.average_rating, 1) if user.average_rating else 0.0,
            'total_projects_completed': projects_count,
            'total_reviews': len(reviews),
            'reviews': reviews_data,
            'badges': badges_data,
            'created_at': user.created_at.isoformat() if user.created_at else None
        }
        
        return jsonify({'user': profile_data}), 200
        
    except Exception as e:
        print(f"Error fetching user profile: {str(e)}")
        return jsonify({'message': 'Failed to fetch user profile'}), 500


@admin_bp.route('/users/<int:user_id>', methods=['PUT'])
@jwt_required()
def update_user_profile(user_id):
    """Update user profile"""
    try:
        current_user = get_current_user()
        if not current_user:
            return jsonify({'message': 'Authentication required'}), 401
        
        # Users can only update their own profile
        if current_user.id != user_id:
            return jsonify({'message': 'Unauthorized'}), 403
        
        data = request.json
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        # Update allowed fields
        if 'first_name' in data:
            user.first_name = data['first_name']
        if 'last_name' in data:
            user.last_name = data['last_name']
        if 'bio' in data:
            user.bio = data['bio']
        if 'skills' in data:
            # Convert array to comma-separated string
            if isinstance(data['skills'], list):
                user.skills = ', '.join(data['skills'])
            else:
                user.skills = data['skills']
        if 'portfolio_url' in data:
            user.portfolio_url = data['portfolio_url']
        if 'hourly_rate' in data:
            user.hourly_rate = float(data['hourly_rate'])
        if 'profile_picture' in data:
            user.profile_picture = data['profile_picture']
        
        db.session.commit()
        
        return jsonify({
            'message': 'Profile updated successfully',
            'user': {
                'id': user.id,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'bio': user.bio,
                'skills': user.skills,
                'portfolio_url': user.portfolio_url,
                'hourly_rate': user.hourly_rate,
                'profile_picture': user.profile_picture
            }
        }), 200
        
    except Exception as e:
        print(f"Error updating profile: {str(e)}")
        db.session.rollback()
        return jsonify({'message': 'Failed to update profile'}), 500