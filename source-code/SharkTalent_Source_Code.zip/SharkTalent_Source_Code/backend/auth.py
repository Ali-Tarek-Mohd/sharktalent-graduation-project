
from flask import Blueprint, request, jsonify
from models import db, User, Badge
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from functools import wraps

auth_bp = Blueprint('auth', __name__)

# ============================================================================
# DECORATORS
# ============================================================================

def role_required(*required_roles):
    """Decorator to require specific roles (compatible with routes.py)"""
    def decorator(f):
        @wraps(f)
        @jwt_required()
        def decorated_function(*args, **kwargs):
            try:
                current_user_id = get_jwt_identity()
                user = User.query.get(current_user_id)
                
                if not user:
                    return jsonify({'message': 'User not found'}), 404
                
                # Check if user has required role
                if required_roles and user.role not in required_roles:
                    return jsonify({
                        'message': f'Access denied. Required role(s): {", ".join(required_roles)}'
                    }), 403
                
                # Pass user as first argument to the decorated function
                return f(user, *args, **kwargs)
                
            except Exception as e:
                print(f"Error in role_required: {str(e)}")
                return jsonify({'message': 'Authorization failed'}), 401
        
        return decorated_function
    return decorator

# ============================================================================
# AUTHENTICATION ROUTES
# ============================================================================

@auth_bp.route('/register', methods=['POST'])
def register():
    """Register a new user"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['email', 'password', 'first_name', 'last_name', 'role']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({'message': f'{field} is required'}), 400
        
        # Validate role
        if data['role'] not in ['client', 'freelancer', 'admin']:
            return jsonify({'message': 'Role must be client, freelancer, or admin'}), 400
        
        # Check if user already exists
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'message': 'User already exists with this email'}), 400
        
        # Validate password strength (minimum 6 characters)
        if len(data['password']) < 6:
            return jsonify({'message': 'Password must be at least 6 characters long'}), 400
        
        # Create user
        user = User(
            email=data['email'].strip().lower(),
            first_name=data['first_name'].strip(),
            last_name=data['last_name'].strip(),
            role=data['role'],
            bio=data.get('bio', '').strip() if data.get('bio') else None,
            skills=data.get('skills', '').strip() if data.get('skills') else None,
            portfolio_url=data.get('portfolio_url', '').strip() if data.get('portfolio_url') else None,
            hourly_rate=float(data['hourly_rate']) if data.get('hourly_rate') else None
        )
        user.set_password(data['password'])
        
        db.session.add(user)
        db.session.commit()
        
        # Create access token
        access_token = create_access_token(identity=user.id)
        
        return jsonify({
            'message': 'User registered successfully',
            'access_token': access_token,
            'user': {
                'id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'role': user.role,
                'bio': user.bio,
                'skills': user.skills,
                'portfolio_url': user.portfolio_url
            }
        }), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"Error in registration: {str(e)}")
        return jsonify({'message': 'Registration failed'}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    """Login user and return JWT token"""
    try:
        data = request.get_json()
        
        # Validate input
        if not data.get('email') or not data.get('password'):
            return jsonify({'message': 'Email and password are required'}), 400
        
        # Find user by email
        user = User.query.filter_by(email=data['email'].strip().lower()).first()
        
        # Verify credentials
        if user and user.check_password(data['password']):
            access_token = create_access_token(identity=user.id)
            
            return jsonify({
                'message': 'Login successful',
                'access_token': access_token,
                'user': {
                    'id': user.id,
                    'email': user.email,
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                    'role': user.role,
                    'bio': user.bio,
                    'skills': user.skills,
                    'portfolio_url': user.portfolio_url,
                    'average_rating': user.average_rating,
                    'total_projects_completed': user.total_projects_completed
                }
            }), 200
        else:
            return jsonify({'message': 'Invalid email or password'}), 401
            
    except Exception as e:
        print(f"Error in login: {str(e)}")
        return jsonify({'message': 'Login failed'}), 500

@auth_bp.route('/profile', methods=['GET'])
@jwt_required()
def get_profile():
    """Get current user's profile"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        # Get badges if freelancer
        badges = []
        if user.role == 'freelancer':
            user_badges = Badge.query.filter_by(freelancer_id=user.id).all()
            badges = [{
                'skill_name': b.skill_name,
                'level': b.badge_level,
                'quiz_score': b.quiz_score,
                'earned_at': b.earned_at.isoformat()
            } for b in user_badges]
        
        return jsonify({
            'user': {
                'id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'role': user.role,
                'bio': user.bio,
                'skills': user.skills,
                'portfolio_url': user.portfolio_url,
                'profile_picture': user.profile_picture,
                'hourly_rate': user.hourly_rate,
                'average_rating': user.average_rating,
                'total_projects_completed': user.total_projects_completed,
                'badges': badges,
                'created_at': user.created_at.isoformat()
            }
        }), 200
        
    except Exception as e:
        print(f"Error fetching profile: {str(e)}")
        return jsonify({'message': 'Failed to get profile'}), 500

@auth_bp.route('/profile/<int:user_id>', methods=['GET'])
@jwt_required()
def get_user_profile(user_id):
    """Get public profile for any user"""
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        # Get badges if freelancer
        badges = []
        if user.role == 'freelancer':
            user_badges = Badge.query.filter_by(freelancer_id=user.id).all()
            badges = [{
                'skill_name': b.skill_name,
                'level': b.badge_level,
                'earned_at': b.earned_at.isoformat()
            } for b in user_badges]
        
        return jsonify({
            'user': {
                'id': user.id,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'role': user.role,
                'bio': user.bio,
                'skills': user.skills,
                'portfolio_url': user.portfolio_url,
                'profile_picture': user.profile_picture,
                'hourly_rate': user.hourly_rate,
                'average_rating': user.average_rating,
                'total_projects_completed': user.total_projects_completed,
                'badges': badges,
                'created_at': user.created_at.isoformat()
            }
        }), 200
        
    except Exception as e:
        print(f"Error fetching user profile: {str(e)}")
        return jsonify({'message': 'Failed to get profile'}), 500

@auth_bp.route('/profile', methods=['PUT'])
@jwt_required()
def update_profile():
    """Update current user's profile"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        data = request.get_json()
        
        # Update basic fields
        if 'first_name' in data and data['first_name']:
            user.first_name = data['first_name'].strip()
        
        if 'last_name' in data and data['last_name']:
            user.last_name = data['last_name'].strip()
        
        if 'email' in data and data['email']:
            email = data['email'].strip().lower()
            existing_user = User.query.filter_by(email=email).first()
            if existing_user and existing_user.id != user.id:
                return jsonify({'message': 'Email already taken'}), 400
            user.email = email
        
        # Update extended profile fields
        if 'bio' in data:
            user.bio = data['bio'].strip() if data['bio'] else None
        
        if 'skills' in data:
            user.skills = data['skills'].strip() if data['skills'] else None
        
        if 'portfolio_url' in data:
            user.portfolio_url = data['portfolio_url'].strip() if data['portfolio_url'] else None
        
        if 'profile_picture' in data:
            user.profile_picture = data['profile_picture'].strip() if data['profile_picture'] else None
        
        if 'hourly_rate' in data and user.role == 'freelancer':
            try:
                user.hourly_rate = float(data['hourly_rate']) if data['hourly_rate'] else None
            except (ValueError, TypeError):
                return jsonify({'message': 'Invalid hourly rate'}), 400
        
        user.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Profile updated successfully',
            'user': {
                'id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'role': user.role,
                'bio': user.bio,
                'skills': user.skills,
                'portfolio_url': user.portfolio_url,
                'hourly_rate': user.hourly_rate
            }
        }), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"Error updating profile: {str(e)}")
        return jsonify({'message': 'Failed to update profile'}), 500

@auth_bp.route('/change-password', methods=['POST'])
@jwt_required()
def change_password():
    """Change user password"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        data = request.get_json()
        
        # Validate input
        if not data.get('current_password') or not data.get('new_password'):
            return jsonify({'message': 'Current password and new password are required'}), 400
        
        # Verify current password
        if not user.check_password(data['current_password']):
            return jsonify({'message': 'Current password is incorrect'}), 400
        
        # Validate new password strength
        if len(data['new_password']) < 6:
            return jsonify({'message': 'New password must be at least 6 characters long'}), 400
        
        # Update password
        user.set_password(data['new_password'])
        user.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({'message': 'Password changed successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        print(f"Error changing password: {str(e)}")
        return jsonify({'message': 'Failed to change password'}), 500

@auth_bp.route('/verify', methods=['GET'])
@jwt_required()
def verify_token():
    """Verify JWT token is valid"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'message': 'Invalid token'}), 401
        
        return jsonify({
            'valid': True,
            'user': {
                'id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'role': user.role
            }
        }), 200
        
    except Exception as e:
        print(f"Error verifying token: {str(e)}")
        return jsonify({'valid': False, 'message': 'Invalid token'}), 401

# Missing import - add this at the top
from datetime import datetime