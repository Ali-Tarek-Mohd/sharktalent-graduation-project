# 🚀 SharkTalent Frontend - Complete Setup Guide

## Step-by-Step Installation

### 1️⃣ Install Node Dependencies

```bash
npm install
```

This will install all packages including:
- React, React Router DOM
- Tailwind CSS, PostCSS, Autoprefixer
- Framer Motion for animations
- Zustand for state management
- Axios for API calls
- React Hot Toast for notifications
- Lucide React for icons

**Expected time:** 2-3 minutes

### 2️⃣ Configure Environment

```bash
# Create .env file
cp .env.example .env
```

Edit `.env` and ensure it points to your backend:
```
VITE_API_URL=http://localhost:5000/api
```

### 3️⃣ Start Development Server

```bash
npm run dev
```

The application will start at: **http://localhost:5173**

## 🎯 What You'll See

### Login Page
- Clean, modern design with gradient background
- Email and password fields
- Register link
- Demo credentials shown

### After Login - Dashboard
- Welcome message with user's name
- 4 stat cards (Projects, Proposals, Messages, Badges)
- Recent activity timeline
- Performance metrics with animated progress bars
- Smooth fade-in animations

### Sidebar Navigation
- **Collapsed mode**: Just icons (80px width)
- **Expanded mode**: Icons + labels (256px width)
- Smooth animation when toggling (300ms)
- Active page highlighted
- User profile section at top
- Logout button at bottom

## 🎨 UI Features

### Animations
1. **Sidebar Toggle** - Smooth width transition
2. **Page Load** - Fade-in effect
3. **Cards** - Hover effect with slight lift
4. **Buttons** - Scale on hover/press
5. **Progress Bars** - Animated fill on load

### Responsive Design
- Mobile: Single column layout
- Tablet: 2-column grid for stats
- Desktop: Full 4-column layout

### Color Scheme
- **Primary Blue**: #0ea5e9 (buttons, highlights)
- **Gray Tones**: For text and backgrounds
- **White Cards**: With subtle shadows
- **Gradient Background**: On login/register pages

## 🔧 Common Tasks

### Add a New Page

1. Create page in `src/pages/`:
```jsx
// src/pages/NewPage.jsx
import { motion } from 'framer-motion';

const NewPage = () => {
  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold">New Page</h1>
      </motion.div>
    </div>
  );
};

export default NewPage;
```

2. Add route in `src/App.jsx`:
```jsx
import NewPage from './pages/NewPage';

// Inside protected routes:
<Route path="new-page" element={<NewPage />} />
```

3. Add to sidebar in `src/components/layout/Sidebar.jsx`:
```jsx
const menuItems = [
  // ...existing items
  { icon: Icon, label: 'New Page', path: '/new-page' },
];
```

### Customize Colors

Edit `tailwind.config.js`:
```javascript
theme: {
  extend: {
    colors: {
      primary: {
        500: '#YOUR_COLOR',
        // Add more shades
      }
    }
  }
}
```

### Add API Endpoint

In `src/utils/api.js`, the axios instance is already configured. Just use it:

```javascript
import api from '../utils/api';

// GET request
const response = await api.get('/projects');

// POST request
const response = await api.post('/projects', { title: 'New Project' });

// Automatic JWT token attachment
// Automatic error handling with toasts
```

## 🐛 Troubleshooting

### Problem: npm install fails

**Solution:**
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and package-lock.json
rm -rf node_modules package-lock.json

# Reinstall
npm install
```

### Problem: Port 5173 is already in use

**Solution:**
```bash
# Kill the process
lsof -ti:5173 | xargs kill -9

# Or use a different port
npm run dev -- --port 3000
```

### Problem: API connection errors

**Check:**
1. Backend is running on port 5000
2. `.env` file exists and has correct API URL
3. Check browser console for specific errors
4. Check Network tab in DevTools

### Problem: Blank page after login

**Check:**
1. Open browser console for errors
2. Verify JWT token is stored: `localStorage.getItem('token')`
3. Check if API is accessible: Try `/api/auth/me` endpoint

### Problem: Animations not working

**Check:**
1. Framer Motion is installed: `npm list framer-motion`
2. No JavaScript errors in console
3. Try hard refresh: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)

## 📱 Testing Checklist

- [ ] Login with valid credentials
- [ ] Login with invalid credentials (should show error)
- [ ] Register new account
- [ ] Dashboard loads with stats
- [ ] Sidebar collapses/expands smoothly
- [ ] All navigation links work
- [ ] Logout redirects to login
- [ ] Responsive on mobile (resize browser)
- [ ] Toast notifications appear
- [ ] Animations are smooth

## 🚀 Next Steps

1. **Connect to Backend**: Ensure your Flask backend is running
2. **Test Authentication**: Try logging in with a real account
3. **Implement Features**: Start building out Projects, Proposals, etc.
4. **Add API Calls**: Connect components to backend endpoints
5. **Handle Loading States**: Add spinners for async operations
6. **Error Handling**: Display user-friendly error messages

## 📖 Resources

- [React Router Docs](https://reactrouter.com/)
- [Tailwind CSS Docs](https://tailwindcss.com/)
- [Framer Motion Docs](https://www.framer.com/motion/)
- [Zustand Docs](https://github.com/pmndrs/zustand)
- [Axios Docs](https://axios-http.com/)

## 💡 Pro Tips

1. **Use React DevTools** - Install browser extension for debugging
2. **Hot Reload** - Save any file and see changes instantly
3. **Tailwind Intellisense** - Install VSCode extension for autocomplete
4. **Component Reuse** - Create reusable components for common UI patterns
5. **State Management** - Keep state close to where it's used

---

**Need help? Check the main README.md or backend documentation!** 🦈
