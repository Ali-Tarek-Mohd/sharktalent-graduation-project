# 🦈 SharkTalent Frontend

Modern, clean, and minimalist React frontend for SharkTalent freelancing platform.

## ✨ Features

- **Clean & Modern UI** - Minimalist design with Tailwind CSS
- **Smooth Animations** - Framer Motion for fluid transitions
- **Animated Sidebar** - Collapsible navigation with smooth animations
- **Responsive Design** - Works perfectly on all devices
- **Role-Based Access** - Different views for clients and freelancers
- **Real-time Toast Notifications** - User-friendly feedback
- **State Management** - Zustand for efficient state handling
- **Protected Routes** - Secure authentication flow

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm
- Backend API running on `http://localhost:5000`

### Installation

1. **Install dependencies:**
```bash
npm install
```

2. **Configure environment:**
```bash
# Copy .env.example to .env
cp .env.example .env

# Edit .env if your backend runs on a different port
VITE_API_URL=http://localhost:5000/api
```

3. **Start development server:**
```bash
npm run dev
```

The app will open at `http://localhost:5173`

## 📁 Project Structure

```
src/
├── components/
│   └── layout/
│       ├── Layout.jsx         # Main layout wrapper
│       └── Sidebar.jsx        # Animated sidebar navigation
├── pages/
│   ├── Login.jsx              # Login page
│   ├── Register.jsx           # Registration page
│   ├── Dashboard.jsx          # Dashboard with stats
│   ├── Projects.jsx           # Projects management
│   ├── Proposals.jsx          # Proposals listing
│   ├── Messages.jsx           # Messaging interface
│   ├── Badges.jsx             # User badges/achievements
│   └── Settings.jsx           # User settings
├── store/
│   └── useStore.js            # Zustand state management
├── utils/
│   └── api.js                 # Axios instance & interceptors
├── App.jsx                    # Main app with routing
└── main.jsx                   # Entry point
```

## 🎨 Design System

### Colors
- **Primary**: Blue tones (#0ea5e9 - #0c4a6e)
- **Shark**: Gray tones for text
- **Status**: Green, Red, Amber

### Animations
- Sidebar: 300ms ease-in-out
- Page transitions: fade-in
- Card hovers: scale effect

## 🔐 Authentication
1. Login/Register
2. JWT stored in localStorage
3. Auto-attached to API requests
4. Protected routes

## 🛠️ Scripts

```bash
npm run dev      # Development
npm run build    # Production build
npm run preview  # Preview build
```

## 📦 Dependencies

- React 18, React Router, Framer Motion
- Tailwind CSS, Zustand, Axios
- React Hot Toast, Lucide Icons

---

**Made with ❤️ for SharkTalent 🦈**
