import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  User,
  Mail,
  MapPin,
  Briefcase,
  Star,
  Award,
  DollarSign,
  Calendar,
  ExternalLink,
  Edit,
  ArrowLeft
} from 'lucide-react';
import api from '../utils/api';
import { useAuthStore } from '../store/useStore';
import toast from 'react-hot-toast';

const UserProfile = () => {
  const { userId } = useParams();
  const navigate = useNavigate();
  const { user: currentUser } = useAuthStore();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUserProfile();
  }, [userId]);

  const fetchUserProfile = async () => {
    try {
      setLoading(true);
      const response = await api.get(`/admin/users/${userId}/profile`);
      setProfile(response.data.user);
    } catch (error) {
      console.error('Error fetching profile:', error);
      toast.error('Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < 5; i++) {
      if (i < fullStars) {
        stars.push(
          <Star key={i} className="w-5 h-5 fill-amber-400 text-amber-400" />
        );
      } else if (i === fullStars && hasHalfStar) {
        stars.push(
          <Star key={i} className="w-5 h-5 fill-amber-200 text-amber-400" />
        );
      } else {
        stars.push(
          <Star key={i} className="w-5 h-5 text-gray-300" />
        );
      }
    }
    return stars;
  };

  const getBadgeGradient = (level) => {
    switch (level) {
      case 'master':
        return 'from-purple-500 to-purple-600';
      case 'expert':
        return 'from-blue-500 to-blue-600';
      default:
        return 'from-green-500 to-green-600';
    }
  };

  const getBadgeIcon = (level) => {
    switch (level) {
      case 'master':
        return '👑';
      case 'expert':
        return '⭐';
      default:
        return '✓';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-12 text-center"
        >
          <User className="w-16 h-16 text-shark-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-shark-900 mb-2">User Not Found</h2>
          <p className="text-shark-600 mb-6">The profile you're looking for doesn't exist.</p>
          <button
            onClick={() => navigate(-1)}
            className="px-6 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl hover:from-primary-600 hover:to-primary-700 transition-all shadow-lg font-semibold"
          >
            Go Back
          </button>
        </motion.div>
      </div>
    );
  }

  const isOwnProfile = currentUser?.id === profile.id;

  return (
    <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100">
      <div className="p-6 space-y-6">
        
        {/* Back Button */}
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-shark-700 hover:text-shark-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="font-medium">Back</span>
        </motion.button>

        {/* Header Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-8"
        >
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            {/* Avatar */}
            <div className="relative">
              <div className="w-32 h-32 bg-gradient-to-br from-primary-400 to-primary-600 rounded-full flex items-center justify-center shadow-2xl">
                {profile.profile_picture ? (
                  <img
                    src={profile.profile_picture}
                    alt={`${profile.first_name} ${profile.last_name}`}
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <User className="w-16 h-16 text-white" />
                )}
              </div>
              <div className={`absolute -bottom-2 -right-2 px-3 py-1 bg-gradient-to-r ${
                profile.role === 'client' ? 'from-blue-500 to-blue-600' : 'from-green-500 to-green-600'
              } text-white rounded-full text-sm font-semibold shadow-lg capitalize`}>
                {profile.role}
              </div>
            </div>

            {/* Info */}
            <div className="flex-1">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h1 className="text-3xl font-bold text-shark-900 mb-1">
                    {profile.first_name} {profile.last_name}
                  </h1>
                  {profile.role === 'freelancer' && profile.hourly_rate && (
                    <p className="text-lg text-shark-600 flex items-center gap-2">
                      <DollarSign className="w-5 h-5" />
                      ${profile.hourly_rate}/hour
                    </p>
                  )}
                </div>
                {isOwnProfile && (
                  <Link
                    to="/profile"
                    className="px-4 py-2 bg-white/80 backdrop-blur-sm border border-shark-200/50 text-shark-700 rounded-xl hover:bg-white hover:shadow-md transition-all flex items-center gap-2 font-semibold"
                  >
                    <Edit className="w-4 h-4" />
                    Edit Profile
                  </Link>
                )}
              </div>

              {/* Rating */}
              {profile.role === 'freelancer' && (
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex items-center gap-1">
                    {renderStars(profile.average_rating)}
                  </div>
                  <span className="text-lg font-bold text-shark-900">
                    {profile.average_rating.toFixed(1)}
                  </span>
                  <span className="text-sm text-shark-500">
                    ({profile.total_reviews} {profile.total_reviews === 1 ? 'review' : 'reviews'})
                  </span>
                </div>
              )}

              {/* Stats */}
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center gap-2 px-4 py-2 bg-white/50 backdrop-blur-sm rounded-xl border border-shark-100/50">
                  <Briefcase className="w-5 h-5 text-primary-600" />
                  <span className="text-sm">
                    <span className="font-bold text-shark-900">{profile.total_projects_completed}</span>
                    <span className="text-shark-600"> Projects Completed</span>
                  </span>
                </div>
                {profile.role === 'freelancer' && profile.badges && profile.badges.length > 0 && (
                  <div className="flex items-center gap-2 px-4 py-2 bg-white/50 backdrop-blur-sm rounded-xl border border-shark-100/50">
                    <Award className="w-5 h-5 text-amber-600" />
                    <span className="text-sm">
                      <span className="font-bold text-shark-900">{profile.badges.length}</span>
                      <span className="text-shark-600"> {profile.badges.length === 1 ? 'Badge' : 'Badges'}</span>
                    </span>
                  </div>
                )}
                <div className="flex items-center gap-2 px-4 py-2 bg-white/50 backdrop-blur-sm rounded-xl border border-shark-100/50">
                  <Calendar className="w-5 h-5 text-purple-600" />
                  <span className="text-sm text-shark-600">
                    Joined {new Date(profile.created_at).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - About & Skills */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* About Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6"
            >
              <h2 className="text-xl font-bold text-shark-900 mb-4">About</h2>
              {profile.bio ? (
                <p className="text-shark-700 leading-relaxed whitespace-pre-wrap">{profile.bio}</p>
              ) : (
                <p className="text-shark-400 italic">No bio provided yet.</p>
              )}
            </motion.div>

            {/* Skills Section */}
            {profile.role === 'freelancer' && profile.skills && profile.skills.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6"
              >
                <h2 className="text-xl font-bold text-shark-900 mb-4">Skills</h2>
                <div className="flex flex-wrap gap-2">
                  {profile.skills.map((skill, index) => (
                    <span
                      key={index}
                      className="px-4 py-2 bg-gradient-to-r from-primary-100 to-primary-200 text-primary-700 rounded-xl font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Portfolio */}
            {profile.portfolio_url && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6"
              >
                <h2 className="text-xl font-bold text-shark-900 mb-4">Portfolio</h2>
                <a
                  href={profile.portfolio_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-primary-600 hover:text-primary-700 font-medium transition-colors"
                >
                  <ExternalLink className="w-5 h-5" />
                  View Portfolio
                </a>
              </motion.div>
            )}

            {/* Reviews Section */}
            {profile.role === 'freelancer' && profile.reviews && profile.reviews.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6"
              >
                <h2 className="text-xl font-bold text-shark-900 mb-6">Reviews</h2>
                <div className="space-y-4">
                  {profile.reviews.map((review) => (
                    <div
                      key={review.id}
                      className="p-4 bg-white/50 backdrop-blur-sm rounded-xl border border-shark-100/50"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-primary-400 to-primary-600 rounded-full flex items-center justify-center flex-shrink-0">
                            {review.reviewer.profile_picture ? (
                              <img
                                src={review.reviewer.profile_picture}
                                alt={review.reviewer.name}
                                className="w-full h-full rounded-full object-cover"
                              />
                            ) : (
                              <User className="w-5 h-5 text-white" />
                            )}
                          </div>
                          <div>
                            <p className="font-semibold text-shark-900">{review.reviewer.name}</p>
                            <p className="text-xs text-shark-500">
                              {review.project?.title}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          {renderStars(review.rating)}
                        </div>
                      </div>
                      
                      {review.comment && (
                        <p className="text-shark-700 mb-3 leading-relaxed">{review.comment}</p>
                      )}

                      {/* Detailed Ratings */}
                      {(review.quality_rating || review.communication_rating || review.deadline_rating) && (
                        <div className="flex flex-wrap gap-4 text-sm">
                          {review.quality_rating && (
                            <div className="flex items-center gap-1">
                              <span className="text-shark-600">Quality:</span>
                              <span className="font-semibold text-shark-900">{review.quality_rating}/5</span>
                            </div>
                          )}
                          {review.communication_rating && (
                            <div className="flex items-center gap-1">
                              <span className="text-shark-600">Communication:</span>
                              <span className="font-semibold text-shark-900">{review.communication_rating}/5</span>
                            </div>
                          )}
                          {review.deadline_rating && (
                            <div className="flex items-center gap-1">
                              <span className="text-shark-600">Deadline:</span>
                              <span className="font-semibold text-shark-900">{review.deadline_rating}/5</span>
                            </div>
                          )}
                        </div>
                      )}

                      <p className="text-xs text-shark-400 mt-3">
                        {new Date(review.created_at).toLocaleDateString('en-US', { 
                          month: 'short', 
                          day: 'numeric', 
                          year: 'numeric' 
                        })}
                      </p>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>

          {/* Right Column - Badges */}
          {profile.role === 'freelancer' && profile.badges && profile.badges.length > 0 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6"
            >
              <h2 className="text-xl font-bold text-shark-900 mb-6">Badges & Certifications</h2>
              <div className="space-y-3">
                {profile.badges.map((badge) => (
                  <div
                    key={badge.id}
                    className={`p-4 bg-gradient-to-r ${getBadgeGradient(badge.badge_level)} rounded-xl shadow-lg`}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-2xl">{getBadgeIcon(badge.badge_level)}</span>
                      <div className="flex-1">
                        <p className="font-bold text-white">{badge.skill_name}</p>
                        <p className="text-xs text-white/80 capitalize">{badge.badge_level}</p>
                      </div>
                    </div>
                    {badge.quiz_score && (
                      <p className="text-sm text-white/90">
                        Quiz Score: <span className="font-bold">{badge.quiz_score}%</span>
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserProfile;