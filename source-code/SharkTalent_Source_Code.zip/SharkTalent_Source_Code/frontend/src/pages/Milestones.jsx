import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Target, 
  CheckCircle, 
  Clock, 
  Trash2, 
  X, 
  Plus, 
  DollarSign,
  Send,
  ThumbsUp,
  AlertCircle,
  TrendingUp
} from 'lucide-react';
import { useAuthStore } from '../store/useStore';
import api from '../utils/api';
import toast from 'react-hot-toast';

const Milestones = () => {
  const { user } = useAuthStore();
  const [loading, setLoading] = useState(true);
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [milestones, setMilestones] = useState([]);
  const [showModal, setShowModal] = useState(false);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    amount: '',
    due_date: ''
  });

  useEffect(() => {
    fetchProjects();
  }, [user.role]);

  const fetchProjects = async () => {
    try {
      setLoading(true);
      let response;
      
      if (user.role === 'client') {
        response = await api.get('/projects/my-projects');
      } else {
        // Freelancers: Get projects from accepted proposals
        const proposalsRes = await api.get('/proposals/my-proposals');
        const acceptedProposals = proposalsRes.data.proposals?.filter(p => p.status === 'accepted') || [];
        
        if (acceptedProposals.length > 0) {
          // Extract projects directly from proposals (they include project data)
          const projects = acceptedProposals
            .filter(p => p.project && p.project.id)
            .map(p => ({
              id: p.project.id,
              title: p.project.title,
              description: p.project.description,
              budget: p.project.budget,
              status: p.project.status,
              deadline: p.project.deadline,
              skills_required: p.project.skills_required,
              client_id: p.project.client_id,
              created_at: p.project.created_at
            }));
          
          response = { data: { projects } };
        } else {
          response = { data: { projects: [] } };
        }
      }
      
      // Filter for in_progress projects only
      const inProgressProjects = response.data.projects?.filter(p => p.status === 'in_progress') || [];
      setProjects(inProgressProjects);
      
      if (inProgressProjects.length > 0) {
        setSelectedProject(inProgressProjects[0]);
        fetchMilestones(inProgressProjects[0].id);
      }
    } catch (error) {
      console.error('Error fetching projects:', error);
      toast.error('Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  const fetchMilestones = async (projectId) => {
    try {
      const response = await api.get(`/milestones/project/${projectId}`);
      setMilestones(response.data.milestones || []);
    } catch (error) {
      console.error('Error fetching milestones:', error);
      toast.error('Failed to load milestones');
    }
  };

  const handleProjectChange = (project) => {
    setSelectedProject(project);
    fetchMilestones(project.id);
  };

  const handleCreateMilestone = async (e) => {
    e.preventDefault();
    
    try {
      await api.post('/milestones/', {
        project_id: selectedProject.id,
        ...formData,
        amount: parseFloat(formData.amount)
      });
      
      toast.success('Milestone created successfully!');
      setShowModal(false);
      resetForm();
      fetchMilestones(selectedProject.id);
    } catch (error) {
      console.error('Error creating milestone:', error);
      toast.error(error.response?.data?.message || 'Failed to create milestone');
    }
  };

  const handleMarkComplete = async (milestoneId) => {
    try {
      await api.put(`/milestones/${milestoneId}/status`, {
        status: 'submitted'
      });
      
      toast.success('Milestone marked as complete! Waiting for client approval.');
      fetchMilestones(selectedProject.id);
    } catch (error) {
      console.error('Error updating milestone:', error);
      toast.error(error.response?.data?.message || 'Failed to update milestone');
    }
  };

  const handleApproveMilestone = async (milestoneId) => {
    try {
      await api.put(`/milestones/${milestoneId}/status`, {
        status: 'approved'
      });
      
      toast.success('Milestone approved!');
      fetchMilestones(selectedProject.id);
    } catch (error) {
      console.error('Error approving milestone:', error);
      toast.error(error.response?.data?.message || 'Failed to approve milestone');
    }
  };

  const handleRejectMilestone = async (milestoneId) => {
    try {
      await api.put(`/milestones/${milestoneId}/status`, {
        status: 'rejected'
      });
      
      toast.success('Milestone rejected. Freelancer can resubmit after making changes.');
      fetchMilestones(selectedProject.id);
    } catch (error) {
      console.error('Error rejecting milestone:', error);
      toast.error(error.response?.data?.message || 'Failed to reject milestone');
    }
  };

  const handleDeleteMilestone = async (milestoneId) => {
    if (!window.confirm('Are you sure you want to delete this milestone?')) return;
    
    try {
      await api.delete(`/milestones/${milestoneId}`);
      toast.success('Milestone deleted successfully!');
      fetchMilestones(selectedProject.id);
    } catch (error) {
      console.error('Error deleting milestone:', error);
      toast.error('Failed to delete milestone');
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      amount: '',
      due_date: ''
    });
  };

  const getStatusConfig = (status) => {
    switch (status) {
      case 'pending':
        return {
          bg: 'from-gray-500 to-gray-600',
          text: 'Pending',
          icon: <Clock className="w-4 h-4" />
        };
      case 'submitted':
        return {
          bg: 'from-amber-500 to-amber-600',
          text: 'Awaiting Approval',
          icon: <AlertCircle className="w-4 h-4" />
        };
      case 'approved':
        return {
          bg: 'from-green-500 to-green-600',
          text: 'Approved',
          icon: <CheckCircle className="w-4 h-4" />
        };
      case 'rejected':
        return {
          bg: 'from-red-500 to-red-600',
          text: 'Rejected',
          icon: <X className="w-4 h-4" />
        };
      default:
        return {
          bg: 'from-gray-500 to-gray-600',
          text: status,
          icon: <Clock className="w-4 h-4" />
        };
    }
  };

  const calculateProgress = () => {
    if (milestones.length === 0) return 0;
    const approved = milestones.filter(m => m.status === 'approved').length;
    return Math.round((approved / milestones.length) * 100);
  };

  const calculateBudgetUsed = () => {
    const approved = milestones.filter(m => m.status === 'approved');
    return approved.reduce((sum, m) => sum + m.amount, 0);
  };

  const totalBudget = milestones.reduce((sum, m) => sum + m.amount, 0);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100">
      <div className="p-6 space-y-6">
        
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl px-6 py-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-shark-900 to-primary-600 bg-clip-text text-transparent">
                Milestones
              </h1>
              <p className="text-sm text-shark-600 mt-1">
                Track project progress and deliverables
              </p>
            </div>
            {user.role === 'client' && selectedProject && (
              <button
                onClick={() => setShowModal(true)}
                className="px-6 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl hover:from-primary-600 hover:to-primary-700 transition-all shadow-lg hover:shadow-xl flex items-center gap-2 font-semibold"
              >
                <Plus className="w-5 h-5" />
                Add Milestone
              </button>
            )}
          </div>
        </motion.div>

        {projects.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-12 text-center"
          >
            <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mx-auto mb-4">
              <Target className="w-10 h-10 text-primary-600" />
            </div>
            <h3 className="text-xl font-semibold text-shark-900 mb-2">No Active Projects</h3>
            <p className="text-shark-500">
              {user.role === 'client' 
                ? 'Create a project and accept a proposal to start managing milestones.'
                : 'You don\'t have any accepted proposals yet.'}
            </p>
          </motion.div>
        ) : (
          <>
            {/* Project Selector */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6"
            >
              <label className="block text-sm font-semibold text-shark-700 mb-3">
                Select Project
              </label>
              <select
                value={selectedProject?.id || ''}
                onChange={(e) => {
                  const project = projects.find(p => p.id === parseInt(e.target.value));
                  handleProjectChange(project);
                }}
                className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
              >
                {projects.map(project => (
                  <option key={project.id} value={project.id}>
                    {project.title}
                  </option>
                ))}
              </select>
            </motion.div>

            {/* Progress Overview */}
            {milestones.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="grid grid-cols-1 md:grid-cols-3 gap-6"
              >
                {/* Progress Card */}
                <div className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center">
                      <TrendingUp className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-sm text-shark-600">Progress</p>
                      <p className="text-2xl font-bold text-shark-900">{calculateProgress()}%</p>
                    </div>
                  </div>
                  <div className="w-full bg-shark-200/50 rounded-full h-3 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${calculateProgress()}%` }}
                      transition={{ duration: 1, delay: 0.3 }}
                      className="bg-gradient-to-r from-primary-500 to-primary-600 h-3 rounded-full"
                    />
                  </div>
                </div>

                {/* Budget Card */}
                <div className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center">
                      <DollarSign className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-sm text-shark-600">Budget Used</p>
                      <p className="text-2xl font-bold text-shark-900">
                        ${calculateBudgetUsed().toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <p className="text-sm text-shark-500">
                    of ${totalBudget.toLocaleString()} total
                  </p>
                </div>

                {/* Milestones Count */}
                <div className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-purple-600 rounded-xl flex items-center justify-center">
                      <Target className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-sm text-shark-600">Milestones</p>
                      <p className="text-2xl font-bold text-shark-900">
                        {milestones.filter(m => m.status === 'approved').length} / {milestones.length}
                      </p>
                    </div>
                  </div>
                  <p className="text-sm text-shark-500">Completed</p>
                </div>
              </motion.div>
            )}

            {/* Milestones List */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6"
            >
              <h2 className="text-xl font-bold text-shark-900 mb-6">Project Milestones</h2>
              
              {milestones.length === 0 ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Target className="w-8 h-8 text-primary-600" />
                  </div>
                  <p className="text-shark-500 mb-4">No milestones yet for this project</p>
                  {user.role === 'client' && (
                    <button
                      onClick={() => setShowModal(true)}
                      className="px-6 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl hover:from-primary-600 hover:to-primary-700 transition-all shadow-lg font-semibold"
                    >
                      Create First Milestone
                    </button>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  {milestones.map((milestone, index) => {
                    const statusConfig = getStatusConfig(milestone.status);
                    
                    return (
                      <motion.div
                        key={milestone.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.4 + index * 0.1 }}
                        className="p-6 bg-white/50 backdrop-blur-sm rounded-xl border border-shark-100/50 hover:shadow-md transition-all"
                      >
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex-1">
                            <h3 className="text-lg font-bold text-shark-900 mb-2">{milestone.title}</h3>
                            <p className="text-sm text-shark-600 mb-3">{milestone.description}</p>
                            
                            <div className="flex items-center gap-4 text-sm">
                              <div className="flex items-center gap-2">
                                <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-green-600 rounded-lg flex items-center justify-center">
                                  <DollarSign className="w-4 h-4 text-white" />
                                </div>
                                <span className="font-semibold text-shark-900">${milestone.amount.toLocaleString()}</span>
                              </div>
                              
                              {milestone.due_date && (
                                <div className="flex items-center gap-2">
                                  <Clock className="w-4 h-4 text-shark-400" />
                                  <span className="text-shark-600">
                                    Due {new Date(milestone.due_date).toLocaleDateString()}
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>
                          
                          <span className={`px-3 py-1.5 bg-gradient-to-r ${statusConfig.bg} text-white rounded-full text-xs font-semibold shadow-md flex items-center gap-1 flex-shrink-0`}>
                            {statusConfig.icon}
                            {statusConfig.text}
                          </span>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-2 pt-4 border-t border-shark-200/50">
                          {/* Freelancer Actions */}
                          {user.role === 'freelancer' && (
                            <>
                              {milestone.status === 'pending' && (
                                <button
                                  onClick={() => handleMarkComplete(milestone.id)}
                                  className="px-4 py-2 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl hover:from-primary-600 hover:to-primary-700 transition-all shadow-lg flex items-center gap-2 font-semibold text-sm"
                                >
                                  <Send className="w-4 h-4" />
                                  Mark as Complete
                                </button>
                              )}
                              {milestone.status === 'rejected' && (
                                <button
                                  onClick={() => handleMarkComplete(milestone.id)}
                                  className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg flex items-center gap-2 font-semibold text-sm"
                                >
                                  <Send className="w-4 h-4" />
                                  Resubmit
                                </button>
                              )}
                              {milestone.status === 'submitted' && (
                                <p className="text-sm text-amber-600 font-medium">
                                  ⏳ Waiting for client approval...
                                </p>
                              )}
                              {milestone.status === 'approved' && (
                                <p className="text-sm text-green-600 font-medium flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4" />
                                  Approved by client
                                </p>
                              )}
                            </>
                          )}

                          {/* Client Actions */}
                          {user.role === 'client' && (
                            <>
                              {milestone.status === 'submitted' && (
                                <div className="flex items-center gap-2">
                                  <button
                                    onClick={() => handleApproveMilestone(milestone.id)}
                                    className="px-4 py-2 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl hover:from-green-600 hover:to-green-700 transition-all shadow-lg flex items-center gap-2 font-semibold text-sm"
                                  >
                                    <ThumbsUp className="w-4 h-4" />
                                    Approve
                                  </button>
                                  <button
                                    onClick={() => handleRejectMilestone(milestone.id)}
                                    className="px-4 py-2 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-xl hover:from-red-600 hover:to-red-700 transition-all shadow-lg flex items-center gap-2 font-semibold text-sm"
                                  >
                                    <X className="w-4 h-4" />
                                    Request Changes
                                  </button>
                                </div>
                              )}
                              {milestone.status === 'pending' && (
                                <p className="text-sm text-shark-500">⏳ Waiting for freelancer to complete...</p>
                              )}
                              {milestone.status === 'approved' && (
                                <p className="text-sm text-green-600 font-medium flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4" />
                                  Approved
                                </p>
                              )}
                              
                              {milestone.status !== 'approved' && (
                                <button
                                  onClick={() => handleDeleteMilestone(milestone.id)}
                                  className="ml-auto px-4 py-2 bg-white/80 backdrop-blur-sm border border-red-200/50 text-red-600 rounded-xl hover:bg-red-50 hover:shadow-md transition-all flex items-center gap-2 font-semibold text-sm"
                                >
                                  <Trash2 className="w-4 h-4" />
                                  Delete
                                </button>
                              )}
                            </>
                          )}
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </motion.div>
          </>
        )}

        {/* Create Milestone Modal */}
        <AnimatePresence>
          {showModal && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => {
                  setShowModal(false);
                  resetForm();
                }}
                className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50"
              />
              
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="fixed inset-0 flex items-center justify-center p-4 z-50 pointer-events-none"
              >
                <div className="bg-white/95 backdrop-blur-xl rounded-2xl p-8 max-w-2xl w-full pointer-events-auto shadow-2xl border border-white/20">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold bg-gradient-to-r from-shark-900 to-primary-600 bg-clip-text text-transparent">
                      Create New Milestone
                    </h2>
                    <button
                      onClick={() => {
                        setShowModal(false);
                        resetForm();
                      }}
                      className="p-2 hover:bg-shark-100 rounded-lg transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <form onSubmit={handleCreateMilestone} className="space-y-5">
                    <div>
                      <label className="block text-sm font-semibold text-shark-700 mb-2">
                        Milestone Title *
                      </label>
                      <input
                        type="text"
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        required
                        placeholder="E.g., Design Mockups"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-shark-700 mb-2">
                        Description
                      </label>
                      <textarea
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all min-h-[100px]"
                        placeholder="Describe what needs to be delivered..."
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-semibold text-shark-700 mb-2">
                          Amount ($) *
                        </label>
                        <input
                          type="number"
                          value={formData.amount}
                          onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                          className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                          required
                          min="0"
                          step="0.01"
                          placeholder="500"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-shark-700 mb-2">
                          Due Date *
                        </label>
                        <input
                          type="date"
                          value={formData.due_date}
                          onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                          className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                          required
                        />
                      </div>
                    </div>

                    <div className="flex gap-3 pt-4">
                      <button
                        type="button"
                        onClick={() => {
                          setShowModal(false);
                          resetForm();
                        }}
                        className="flex-1 px-6 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 text-shark-700 rounded-xl hover:bg-white hover:shadow-md transition-all font-semibold"
                      >
                        Cancel
                      </button>
                      <button 
                        type="submit" 
                        className="flex-1 px-6 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl hover:from-primary-600 hover:to-primary-700 transition-all shadow-lg hover:shadow-xl font-semibold"
                      >
                        Create Milestone
                      </button>
                    </div>
                  </form>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Milestones;