import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Send, Search, MessageCircle, User } from 'lucide-react';
import { useAuthStore } from '../store/useStore';
import api from '../utils/api';
import toast from 'react-hot-toast';

const Messages = () => {
  const { user } = useAuthStore();
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sendingMessage, setSendingMessage] = useState(false);
  const [otherUser, setOtherUser] = useState(null);
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  useEffect(() => {
    if (user && user.role) {
      fetchProjects();
    } else {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (selectedProject && user) {
      fetchOtherUserInfo(selectedProject.id);
      fetchMessages(selectedProject.id);
      const interval = setInterval(() => {
        fetchMessages(selectedProject.id, true);
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [selectedProject, user]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 128) + 'px';
    }
  }, [newMessage]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const fetchOtherUserInfo = async (projectId) => {
    try {
      if (user.role === 'client') {
        const response = await api.get(`/proposals/project/${projectId}`);
        const proposals = response.data.proposals || [];
        
        if (proposals.length > 0) {
          const acceptedProposal = proposals.find(p => p.status === 'accepted');
          const targetProposal = acceptedProposal || proposals[0];
          
          if (targetProposal && targetProposal.freelancer) {
            setOtherUser({
              id: targetProposal.freelancer.id,
              name: targetProposal.freelancer.name,
              role: 'freelancer'
            });
          }
        }
      } else {
        const project = await api.get(`/projects/${projectId}`);
        if (project.data) {
          const clientId = project.data.client_id;
          const clientResponse = await api.get(`/auth/profile/${clientId}`);
          if (clientResponse.data && clientResponse.data.user) {
            const client = clientResponse.data.user;
            setOtherUser({
              id: client.id,
              name: `${client.first_name} ${client.last_name}`,
              role: 'client'
            });
          }
        }
      }
    } catch (error) {
      console.error('Error fetching other user info:', error);
    }
  };

  const fetchProjects = async () => {
    try {
      setLoading(true);
      let response;
      
      if (user.role === 'client') {
        response = await api.get('/projects/my-projects');
      } else {
        const proposalsResponse = await api.get('/proposals/my-proposals');
        const proposals = proposalsResponse.data.proposals || [];
        
        const projectIds = proposals
          .filter(p => p.project && p.project.id)
          .map(p => p.project.id);
        
        const uniqueProjectIds = [...new Set(projectIds)];
        
        if (uniqueProjectIds.length > 0) {
          const projectPromises = uniqueProjectIds.map(id => 
            api.get(`/projects/${id}`).catch(err => {
              console.error(`Error fetching project ${id}:`, err);
              return null;
            })
          );
          const projectsData = await Promise.all(projectPromises);
          response = { 
            data: { 
              projects: projectsData
                .filter(p => p && p.data)
                .map(p => p.data) 
            } 
          };
        } else {
          response = { data: { projects: [] } };
        }
      }
      
      setProjects(response.data.projects || []);
      
      if (response.data.projects?.length > 0) {
        setSelectedProject(response.data.projects[0]);
      }
    } catch (error) {
      console.error('Error fetching projects:', error);
      toast.error('Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (projectId, silent = false) => {
    if (!user || !projectId) return;
    
    try {
      const response = await api.get(`/messages/project/${projectId}`);
      setMessages(response.data.messages || []);
      
      const unreadMessages = response.data.messages?.filter(
        m => !m.is_read && m.receiver.id === user.id
      ) || [];
      
      for (const msg of unreadMessages) {
        try {
          await api.put(`/messages/${msg.id}/read`);
        } catch (error) {
          console.error('Error marking message as read:', error);
        }
      }
    } catch (error) {
      if (!silent) {
        console.error('Error fetching messages:', error);
        toast.error('Failed to load messages');
      }
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    
    if (!newMessage.trim() || !selectedProject || !user) return;

    let receiverId;
    
    if (user.role === 'client') {
      try {
        const response = await api.get(`/proposals/project/${selectedProject.id}`);
        const proposals = response.data.proposals || [];
        
        if (proposals.length === 0) {
          toast.error('No proposals found for this project');
          return;
        }
        
        const acceptedProposal = proposals.find(p => p.status === 'accepted');
        if (acceptedProposal) {
          receiverId = acceptedProposal.freelancer?.id;
        } else {
          receiverId = proposals[0].freelancer?.id;
        }
        
        if (!receiverId) {
          console.error('Could not extract freelancer ID from proposals:', proposals);
          toast.error('Could not find freelancer information');
          return;
        }
      } catch (error) {
        console.error('Error finding proposals:', error);
        toast.error('Failed to find freelancers for this project');
        return;
      }
    } else {
      receiverId = selectedProject.client_id;
    }

    if (!receiverId) {
      toast.error('Cannot determine message recipient');
      return;
    }

    try {
      setSendingMessage(true);
      
      await api.post('/messages/', {
        project_id: selectedProject.id,
        receiver_id: receiverId,
        content: newMessage.trim()
      });

      setNewMessage('');
      await fetchMessages(selectedProject.id);
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error(error.response?.data?.message || 'Failed to send message');
    } finally {
      setSendingMessage(false);
    }
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now - date) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      return date.toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: '2-digit',
        hour12: true 
      });
    } else {
      return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit'
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    // Root container with gradient background
    <div className="fixed inset-0 left-0 md:left-64 top-0 bottom-0 flex flex-col bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100">
      
      {/* ✨ Floating Page Header */}
      <div className="px-6 py-6 flex-shrink-0">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl px-6 py-4"
        >
          <h1 className="text-2xl font-bold bg-gradient-to-r from-shark-900 to-primary-600 bg-clip-text text-transparent">
            Messages
          </h1>
        </motion.div>
      </div>

      {/* Main Content Area with padding for floating effect */}
      <div className="flex-1 flex gap-6 px-6 pb-6 min-h-0 overflow-hidden">
        
        {/* ✨ LEFT: Floating Projects Sidebar */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="w-80 bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl flex flex-col flex-shrink-0 overflow-hidden"
        >
          
          {/* Search */}
          <div className="p-4 border-b border-shark-100/50 flex-shrink-0">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-shark-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search projects..."
                className="w-full pl-10 pr-4 py-2.5 bg-white/60 border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent focus:bg-white transition-all"
              />
            </div>
          </div>

          {/* Projects List - Scrollable */}
          <div className="flex-1 overflow-y-auto">
            {projects.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center px-4">
                <MessageCircle className="w-16 h-16 text-shark-300 mb-4" />
                <p className="text-shark-500">No projects yet</p>
                <p className="text-sm text-shark-400 mt-2">
                  {user.role === 'client' 
                    ? 'Create a project to start messaging'
                    : 'Submit a proposal to start messaging'}
                </p>
              </div>
            ) : (
              projects.map((project) => (
                <button
                  key={project.id}
                  onClick={() => setSelectedProject(project)}
                  className={`w-full p-4 text-left border-b border-shark-100/30 hover:bg-primary-50/50 transition-all ${
                    selectedProject?.id === project.id 
                      ? 'bg-gradient-to-r from-primary-50 to-transparent border-l-4 border-l-primary-600' 
                      : ''
                  }`}
                >
                  <h3 className="font-semibold text-shark-900 mb-1 truncate">
                    {project.title}
                  </h3>
                  <p className="text-sm text-shark-500 truncate">
                    ${project.budget?.toLocaleString()} • {project.status}
                  </p>
                </button>
              ))
            )}
          </div>
        </motion.div>

        {/* ✨ RIGHT: Floating Chat Area */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="flex-1 bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl flex flex-col min-w-0 overflow-hidden"
        >
          {selectedProject ? (
            <>
              {/* Chat Header - Fixed */}
              <div className="bg-gradient-to-r from-white/90 to-primary-50/30 backdrop-blur-xl border-b border-shark-100/50 px-6 py-4 flex-shrink-0">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary-400 to-primary-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
                    <User className="w-7 h-7 text-white" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h2 className="font-bold text-shark-900 text-lg truncate">
                      {otherUser ? otherUser.name : 'Loading...'}
                    </h2>
                    <p className="text-sm text-shark-600 truncate">
                      {selectedProject.title}
                    </p>
                  </div>

                  {otherUser && (
                    <span className="px-3 py-1.5 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-full text-xs font-semibold capitalize flex-shrink-0 shadow-md">
                      {otherUser.role}
                    </span>
                  )}
                </div>
              </div>

              {/* Messages Area - Scrollable */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {messages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mb-4">
                      <MessageCircle className="w-10 h-10 text-primary-600" />
                    </div>
                    <p className="text-shark-500 font-medium">No messages yet</p>
                    <p className="text-sm text-shark-400 mt-2">Start the conversation!</p>
                  </div>
                ) : (
                  <>
                    {messages.map((message, index) => {
                      const isOwnMessage = message.sender.id === user.id;
                      const showAvatar = index === 0 || messages[index - 1].sender.id !== message.sender.id;

                      return (
                        <motion.div
                          key={message.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className={`flex gap-3 ${isOwnMessage ? 'flex-row-reverse' : ''}`}
                        >
                          {showAvatar ? (
                            <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center shadow-md">
                              <User className="w-6 h-6 text-white" />
                            </div>
                          ) : (
                            <div className="w-10 flex-shrink-0"></div>
                          )}

                          <div className={`flex flex-col ${isOwnMessage ? 'items-end' : 'items-start'} max-w-[70%] min-w-0`}>
                            {showAvatar && (
                              <span className="text-xs text-shark-500 mb-1 px-2 font-medium">
                                {message.sender.name}
                              </span>
                            )}
                            <div
                              className={`px-4 py-3 rounded-2xl shadow-md overflow-hidden ${
                                isOwnMessage
                                  ? 'bg-gradient-to-br from-primary-500 to-primary-600 text-white rounded-tr-sm'
                                  : 'bg-white/90 backdrop-blur-sm border border-shark-200/50 text-shark-900 rounded-tl-sm'
                              }`}
                              style={{ wordBreak: 'break-word', overflowWrap: 'break-word' }}
                            >
                              <p className="whitespace-pre-wrap" style={{ wordBreak: 'break-word', overflowWrap: 'break-word' }}>{message.content}</p>
                            </div>
                            <span className="text-xs text-shark-400 mt-1 px-2">
                              {formatTime(message.created_at)}
                              {isOwnMessage && message.is_read && (
                                <span className="ml-1 text-primary-600">✓✓</span>
                              )}
                            </span>
                          </div>
                        </motion.div>
                      );
                    })}
                    <div ref={messagesEndRef} />
                  </>
                )}
              </div>

              {/* ✨ Text Input - Fixed at Bottom with glass effect */}
              <div className="bg-gradient-to-r from-white/90 to-primary-50/20 backdrop-blur-xl border-t border-shark-100/50 px-6 py-4 flex-shrink-0">
                <form onSubmit={handleSendMessage} className="flex gap-3 items-end">
                  <textarea
                    ref={textareaRef}
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage(e);
                      }
                    }}
                    placeholder="Type a message..."
                    rows={1}
                    className="flex-1 px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent resize-none max-h-32 overflow-y-auto shadow-sm focus:bg-white transition-all"
                    style={{ minHeight: '44px' }}
                    disabled={sendingMessage}
                  />
                  <button
                    type="submit"
                    disabled={!newMessage.trim() || sendingMessage}
                    className="px-6 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl hover:from-primary-600 hover:to-primary-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 font-semibold flex-shrink-0 shadow-lg hover:shadow-xl"
                  >
                    <Send className="w-5 h-5" />
                    Send
                  </button>
                </form>
                <p className="text-xs text-shark-500 mt-2">Press Enter to send, Shift+Enter for new line</p>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="w-12 h-12 text-primary-600" />
                </div>
                <p className="text-shark-500 text-lg font-medium">Select a project to view messages</p>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default Messages;