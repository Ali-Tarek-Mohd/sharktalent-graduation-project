import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Star, 
  MessageSquare, 
  X, 
  User,
  Award,
  ThumbsUp,
  CheckCircle,
  AlertCircle,
  Clock
} from 'lucide-react';
import { useAuthStore } from '../store/useStore';
import api from '../utils/api';
import toast from 'react-hot-toast';

const Reviews = () => {
  const { user } = useAuthStore();
  const [loading, setLoading] = useState(true);
  const [reviews, setReviews] = useState([]);
  const [completedProjects, setCompletedProjects] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  
  const [formData, setFormData] = useState({
    rating: 5,
    comment: '',
    quality_rating: 5,
    communication_rating: 5,
    deadline_rating: 5
  });

  useEffect(() => {
    fetchReviews();
    if (user.role === 'client') {
      fetchCompletedProjects();
    }
  }, [user.id]);

  const fetchReviews = async () => {
    try {
      setLoading(true);
      
      // For clients: get reviews they've given
      // For freelancers: get reviews they've received
      if (user.role === 'client') {
        const response = await api.get(`/reviews/by-reviewer/${user.id}`);
        setReviews(response.data.reviews || []);
      } else {
        const response = await api.get(`/reviews/user/${user.id}`);
        setReviews(response.data.reviews || []);
      }
    } catch (error) {
      console.error('Error fetching reviews:', error);
      // Don't show error for empty reviews (404)
      if (error.response?.status !== 404) {
        toast.error('Failed to load reviews');
      }
      setReviews([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchCompletedProjects = async () => {
    try {
      const response = await api.get('/projects/my-projects');
      const completed = response.data.projects?.filter(p => p.status === 'completed') || [];
      
      // Filter out projects that already have reviews
      const projectsWithoutReviews = [];
      for (const project of completed) {
        try {
          const reviewResponse = await api.get(`/reviews/project/${project.id}`);
          // If we got a response with an id, review exists - don't add to list
          if (!reviewResponse.data || !reviewResponse.data.id) {
            projectsWithoutReviews.push(project);
          }
        } catch (error) {
          // If 404, means no review exists yet - add to list
          if (error.response?.status === 404) {
            projectsWithoutReviews.push(project);
          }
        }
      }
      
      setCompletedProjects(projectsWithoutReviews);
    } catch (error) {
      console.error('Error fetching completed projects:', error);
    }
  };

  const handleSubmitReview = async (e) => {
    e.preventDefault();
    
    if (!selectedProject) {
      toast.error('Please select a project');
      return;
    }
    
    try {
      // Get freelancer ID from accepted proposal
      const proposalsRes = await api.get(`/proposals/project/${selectedProject.id}`);
      const acceptedProposal = proposalsRes.data.proposals?.find(p => p.status === 'accepted');
      
      if (!acceptedProposal) {
        toast.error('No accepted proposal found for this project');
        return;
      }
      
      // Use nested freelancer.id
      const freelancerId = acceptedProposal.freelancer?.id;
      
      if (!freelancerId) {
        toast.error('Could not find freelancer information');
        return;
      }
      
      await api.post('/reviews/', {
        project_id: selectedProject.id,
        reviewee_id: freelancerId,
        rating: parseInt(formData.rating),
        comment: formData.comment,
        quality_rating: parseInt(formData.quality_rating),
        communication_rating: parseInt(formData.communication_rating),
        deadline_rating: parseInt(formData.deadline_rating)
      });
      
      toast.success('Review submitted successfully!');
      setShowModal(false);
      resetForm();
      fetchCompletedProjects();
      fetchReviews();
    } catch (error) {
      console.error('Error submitting review:', error);
      toast.error(error.response?.data?.message || 'Failed to submit review');
    }
  };

  const resetForm = () => {
    setFormData({
      rating: 5,
      comment: '',
      quality_rating: 5,
      communication_rating: 5,
      deadline_rating: 5
    });
    setSelectedProject(null);
  };

  const renderStars = (rating, interactive = false, onChange = null) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <Star
          key={i}
          className={`w-6 h-6 transition-all cursor-pointer ${
            i <= rating 
              ? 'fill-amber-400 text-amber-400' 
              : 'text-gray-300'
          } ${interactive ? 'hover:scale-110' : ''}`}
          onClick={() => interactive && onChange && onChange(i)}
        />
      );
    }
    return <div className="flex gap-1">{stars}</div>;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100">
      <div className="p-6 space-y-6">
        
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl px-6 py-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-shark-900 to-primary-600 bg-clip-text text-transparent">
                Reviews
              </h1>
              <p className="text-sm text-shark-600 mt-1">
                {user.role === 'client' 
                  ? 'Leave reviews for completed projects' 
                  : 'Reviews you\'ve received from clients'}
              </p>
            </div>
            {user.role === 'client' && completedProjects.length > 0 && (
              <button
                onClick={() => setShowModal(true)}
                className="px-6 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl hover:from-primary-600 hover:to-primary-700 transition-all shadow-lg hover:shadow-xl flex items-center gap-2 font-semibold"
              >
                <Star className="w-5 h-5" />
                Write Review
              </button>
            )}
          </div>
        </motion.div>

        {/* Client: Projects Awaiting Review */}
        {user.role === 'client' && completedProjects.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6"
          >
            <h2 className="text-xl font-bold text-shark-900 mb-4 flex items-center gap-2">
              <Clock className="w-6 h-6 text-amber-600" />
              Projects Awaiting Review
            </h2>
            <div className="space-y-3">
              {completedProjects.map((project) => (
                <div
                  key={project.id}
                  className="p-4 bg-white/50 backdrop-blur-sm rounded-xl border border-amber-200/50 hover:shadow-md transition-all"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-bold text-shark-900">{project.title}</h3>
                      <p className="text-sm text-shark-600">
                        Completed on {new Date(project.completed_at).toLocaleDateString()}
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setSelectedProject(project);
                        setShowModal(true);
                      }}
                      className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-xl hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg font-semibold text-sm"
                    >
                      Write Review
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Reviews Display */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6"
        >
          <h2 className="text-xl font-bold text-shark-900 mb-6 flex items-center gap-2">
            <MessageSquare className="w-6 h-6 text-primary-600" />
            {user.role === 'client' ? 'Reviews You\'ve Given' : 'Reviews You\'ve Received'}
          </h2>

          {reviews.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-10 h-10 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold text-shark-900 mb-2">No Reviews Yet</h3>
              <p className="text-shark-500">
                {user.role === 'client' 
                  ? 'Complete projects and leave reviews for freelancers.' 
                  : 'Reviews from clients will appear here.'}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {reviews.map((review, index) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  className="p-6 bg-white/50 backdrop-blur-sm rounded-xl border border-shark-100/50 hover:shadow-md transition-all"
                >
                  <div className="flex items-start gap-4">
                    {/* Avatar */}
                    <div className="w-12 h-12 bg-gradient-to-br from-primary-400 to-primary-600 rounded-full flex items-center justify-center flex-shrink-0">
                      <User className="w-7 h-7 text-white" />
                    </div>

                    <div className="flex-1">
                      {/* Header */}
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-bold text-shark-900">
                            {user.role === 'client' ? review.reviewee?.name : review.reviewer?.name}
                          </h3>
                          <p className="text-sm text-shark-500">
                            {review.project?.title}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex gap-0.5">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-5 h-5 ${
                                  i < review.rating
                                    ? 'fill-amber-400 text-amber-400'
                                    : 'text-gray-300'
                                }`}
                              />
                            ))}
                          </div>
                          <span className="font-bold text-shark-900">{review.rating}.0</span>
                        </div>
                      </div>

                      {/* Comment */}
                      {review.comment && (
                        <p className="text-shark-700 mb-4 leading-relaxed">{review.comment}</p>
                      )}

                      {/* Detailed Ratings */}
                      {(review.quality_rating || review.communication_rating || review.deadline_rating) && (
                        <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-shark-200/50">
                          {review.quality_rating && (
                            <div className="text-center">
                              <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                                <Award className="w-5 h-5 text-white" />
                              </div>
                              <p className="text-xs text-shark-600">Quality</p>
                              <p className="font-bold text-shark-900">{review.quality_rating}/5</p>
                            </div>
                          )}
                          {review.communication_rating && (
                            <div className="text-center">
                              <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-green-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                                <MessageSquare className="w-5 h-5 text-white" />
                              </div>
                              <p className="text-xs text-shark-600">Communication</p>
                              <p className="font-bold text-shark-900">{review.communication_rating}/5</p>
                            </div>
                          )}
                          {review.deadline_rating && (
                            <div className="text-center">
                              <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-purple-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                                <Clock className="w-5 h-5 text-white" />
                              </div>
                              <p className="text-xs text-shark-600">Deadline</p>
                              <p className="font-bold text-shark-900">{review.deadline_rating}/5</p>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Date */}
                      <p className="text-xs text-shark-400 mt-4">
                        {new Date(review.created_at).toLocaleDateString('en-US', { 
                          month: 'long', 
                          day: 'numeric', 
                          year: 'numeric' 
                        })}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>

        {/* Write Review Modal */}
        <AnimatePresence>
          {showModal && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => {
                  setShowModal(false);
                  resetForm();
                }}
                className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50"
              />
              
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="fixed inset-0 flex items-center justify-center p-4 z-50 pointer-events-none"
              >
                <div className="bg-white/95 backdrop-blur-xl rounded-2xl p-8 max-w-2xl w-full pointer-events-auto shadow-2xl border border-white/20 max-h-[90vh] overflow-y-auto">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold bg-gradient-to-r from-shark-900 to-primary-600 bg-clip-text text-transparent">
                      Write a Review
                    </h2>
                    <button
                      onClick={() => {
                        setShowModal(false);
                        resetForm();
                      }}
                      className="p-2 hover:bg-shark-100 rounded-lg transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <form onSubmit={handleSubmitReview} className="space-y-6">
                    {/* Project Selection */}
                    {!selectedProject && (
                      <div>
                        <label className="block text-sm font-semibold text-shark-700 mb-2">
                          Select Project *
                        </label>
                        <select
                          value={selectedProject?.id || ''}
                          onChange={(e) => {
                            const project = completedProjects.find(p => p.id === parseInt(e.target.value));
                            setSelectedProject(project);
                          }}
                          className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                          required
                        >
                          <option value="">Choose a project...</option>
                          {completedProjects.map(project => (
                            <option key={project.id} value={project.id}>
                              {project.title}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}

                    {selectedProject && (
                      <div className="p-4 bg-primary-50 border border-primary-200 rounded-xl">
                        <p className="text-sm text-shark-600">Reviewing project:</p>
                        <p className="font-bold text-shark-900">{selectedProject.title}</p>
                      </div>
                    )}

                    {/* Overall Rating */}
                    <div>
                      <label className="block text-sm font-semibold text-shark-700 mb-3">
                        Overall Rating *
                      </label>
                      {renderStars(formData.rating, true, (rating) => setFormData({ ...formData, rating }))}
                      <p className="text-sm text-shark-500 mt-2">{formData.rating} out of 5 stars</p>
                    </div>

                    {/* Detailed Ratings */}
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className="block text-sm font-semibold text-shark-700 mb-2">
                          Quality
                        </label>
                        <input
                          type="number"
                          min="1"
                          max="5"
                          value={formData.quality_rating}
                          onChange={(e) => setFormData({ ...formData, quality_rating: e.target.value })}
                          className="w-full px-4 py-2 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-shark-700 mb-2">
                          Communication
                        </label>
                        <input
                          type="number"
                          min="1"
                          max="5"
                          value={formData.communication_rating}
                          onChange={(e) => setFormData({ ...formData, communication_rating: e.target.value })}
                          className="w-full px-4 py-2 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-shark-700 mb-2">
                          Deadline
                        </label>
                        <input
                          type="number"
                          min="1"
                          max="5"
                          value={formData.deadline_rating}
                          onChange={(e) => setFormData({ ...formData, deadline_rating: e.target.value })}
                          className="w-full px-4 py-2 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        />
                      </div>
                    </div>

                    {/* Comment */}
                    <div>
                      <label className="block text-sm font-semibold text-shark-700 mb-2">
                        Your Review
                      </label>
                      <textarea
                        value={formData.comment}
                        onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                        className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all min-h-[120px]"
                        placeholder="Share your experience working with this freelancer..."
                      />
                    </div>

                    <div className="flex gap-3 pt-4">
                      <button
                        type="button"
                        onClick={() => {
                          setShowModal(false);
                          resetForm();
                        }}
                        className="flex-1 px-6 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 text-shark-700 rounded-xl hover:bg-white hover:shadow-md transition-all font-semibold"
                      >
                        Cancel
                      </button>
                      <button 
                        type="submit" 
                        className="flex-1 px-6 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl hover:from-primary-600 hover:to-primary-700 transition-all shadow-lg hover:shadow-xl font-semibold"
                      >
                        Submit Review
                      </button>
                    </div>
                  </form>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Reviews;