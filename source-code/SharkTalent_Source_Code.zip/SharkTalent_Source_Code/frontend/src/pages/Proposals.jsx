import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Clock, CheckCircle, XCircle, Trash2, X, DollarSign, Calendar, FileText, User, ChevronDown } from 'lucide-react';
import { useAuthStore } from '../store/useStore';
import api from '../utils/api';
import toast from 'react-hot-toast';

const Proposals = () => {
  const { user } = useAuthStore();
  const [proposals, setProposals] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [remainingSlots, setRemainingSlots] = useState(3);
  
  const [formData, setFormData] = useState({
    project_id: '',
    cover_letter: '',
    bid_amount: '',
    timeline_days: ''
  });

  useEffect(() => {
    fetchData();
  }, [user.role]);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      if (user.role === 'freelancer') {
        const response = await api.get('/proposals/my-proposals');
        setProposals(response.data.proposals || []);
        setRemainingSlots(response.data.remaining_slots || 0);
      } else if (user.role === 'client') {
        const response = await api.get('/projects/my-projects');
        setProjects(response.data.projects || []);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const fetchProjectProposals = async (projectId) => {
    try {
      const response = await api.get(`/proposals/project/${projectId}`);
      return response.data.proposals || [];
    } catch (error) {
      console.error('Error fetching project proposals:', error);
      toast.error('Failed to load proposals');
      return [];
    }
  };

  const handleSubmitProposal = async (e) => {
    e.preventDefault();

    if (remainingSlots <= 0) {
      toast.error('You have reached the maximum of 3 pending proposals');
      return;
    }

    try {
      const response = await api.post('/proposals/', {
        project_id: parseInt(formData.project_id),
        cover_letter: formData.cover_letter,
        bid_amount: parseFloat(formData.bid_amount),
        timeline_days: parseInt(formData.timeline_days)
      });

      toast.success(response.data.message);
      setShowModal(false);
      setFormData({ project_id: '', cover_letter: '', bid_amount: '', timeline_days: '' });
      fetchData();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to submit proposal');
    }
  };

  const handleWithdrawProposal = async (proposalId) => {
    if (!window.confirm('Are you sure you want to withdraw this proposal?')) return;

    try {
      await api.delete(`/proposals/${proposalId}`);
      toast.success('Proposal withdrawn successfully');
      fetchData();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to withdraw proposal');
    }
  };

  const handleUpdateProposalStatus = async (proposalId, status) => {
    const action = status === 'accepted' ? 'accept' : 'reject';
    if (!window.confirm(`Are you sure you want to ${action} this proposal?`)) return;

    try {
      await api.put(`/proposals/${proposalId}/status`, { status });
      toast.success(`Proposal ${status} successfully`);
      fetchData();
    } catch (error) {
      toast.error(error.response?.data?.message || `Failed to ${action} proposal`);
    }
  };

  const openSubmitModal = async () => {
    try {
      const response = await api.get('/projects/?status=open');
      const openProjects = response.data.projects || [];
      
      if (openProjects.length === 0) {
        toast.error('No open projects available');
        return;
      }
      
      setProjects(openProjects);
      setShowModal(true);
    } catch (error) {
      toast.error('Failed to load projects');
    }
  };

  const statusConfig = {
    pending: { bg: 'from-amber-500 to-amber-600', text: 'Pending', icon: <Clock className="w-4 h-4" /> },
    accepted: { bg: 'from-green-500 to-green-600', text: 'Accepted', icon: <CheckCircle className="w-4 h-4" /> },
    rejected: { bg: 'from-red-500 to-red-600', text: 'Rejected', icon: <XCircle className="w-4 h-4" /> },
    withdrawn: { bg: 'from-gray-500 to-gray-600', text: 'Withdrawn', icon: <XCircle className="w-4 h-4" /> },
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100">
      <div className="p-6 space-y-6">
        
        {/* ✨ Glass Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl px-6 py-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-shark-900 to-primary-600 bg-clip-text text-transparent">
                {user.role === 'freelancer' ? 'My Proposals' : 'Project Proposals'}
              </h1>
              <p className="text-sm text-shark-600 mt-1">
                {user.role === 'freelancer' 
                  ? `You have ${remainingSlots} proposal slot${remainingSlots !== 1 ? 's' : ''} remaining`
                  : 'Review proposals from freelancers'}
              </p>
            </div>

            {user.role === 'freelancer' && (
              <button
                onClick={openSubmitModal}
                disabled={remainingSlots <= 0}
                className={`px-6 py-3 rounded-xl font-semibold transition-all shadow-lg hover:shadow-xl flex items-center gap-2 ${
                  remainingSlots > 0
                    ? 'bg-gradient-to-r from-primary-500 to-primary-600 text-white hover:from-primary-600 hover:to-primary-700'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
              >
                <Send className="w-5 h-5" />
                Submit Proposal
              </button>
            )}
          </div>
        </motion.div>

        {/* Freelancer View - My Proposals */}
        {user.role === 'freelancer' && (
          <div className="space-y-4">
            {proposals.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-12 text-center"
              >
                <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Send className="w-10 h-10 text-primary-600" />
                </div>
                <p className="text-shark-500 text-lg font-medium mb-4">No proposals submitted yet</p>
                <button
                  onClick={openSubmitModal}
                  disabled={remainingSlots <= 0}
                  className="px-6 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl hover:from-primary-600 hover:to-primary-700 transition-all shadow-lg disabled:bg-gray-300 font-semibold"
                >
                  Submit Your First Proposal
                </button>
              </motion.div>
            ) : (
              proposals.map((proposal, index) => {
                const statusInfo = statusConfig[proposal.status] || statusConfig.pending;
                
                return (
                  <motion.div
                    key={proposal.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6 hover:shadow-2xl transition-all"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-shark-900 mb-3">
                          {proposal.project?.title || 'Project'}
                        </h3>
                        <div className="flex items-center gap-4 flex-wrap">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-green-600 rounded-lg flex items-center justify-center flex-shrink-0">
                              <DollarSign className="w-4 h-4 text-white" />
                            </div>
                            <span className="text-sm font-semibold text-shark-900">
                              ${proposal.bid_amount?.toLocaleString()}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                              <Calendar className="w-4 h-4 text-white" />
                            </div>
                            <span className="text-sm text-shark-600">{proposal.timeline_days} days</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <span className={`px-3 py-1.5 bg-gradient-to-r ${statusInfo.bg} text-white rounded-full text-xs font-semibold shadow-md flex items-center gap-1`}>
                          {statusInfo.icon}
                          {statusInfo.text}
                        </span>
                        
                        {proposal.status === 'pending' && (
                          <button
                            onClick={() => handleWithdrawProposal(proposal.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                            title="Withdraw proposal"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="bg-white/50 backdrop-blur-sm rounded-xl p-4 border border-shark-100/50">
                      <p className="text-sm font-semibold text-shark-700 mb-2">Cover Letter:</p>
                      <p className="text-shark-600 whitespace-pre-wrap text-sm">{proposal.cover_letter}</p>
                    </div>

                    <div className="mt-4 text-xs text-shark-500">
                      Submitted {new Date(proposal.submitted_at).toLocaleDateString()}
                    </div>
                  </motion.div>
                );
              })
            )}
          </div>
        )}

        {/* Client View - Projects with Proposals */}
        {user.role === 'client' && (
          <div className="space-y-6">
            {projects.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-12 text-center"
              >
                <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mx-auto mb-4">
                  <FileText className="w-10 h-10 text-primary-600" />
                </div>
                <p className="text-shark-500 text-lg">No projects yet</p>
              </motion.div>
            ) : (
              projects.map((project, index) => (
                <ProjectProposals
                  key={project.id}
                  project={project}
                  fetchProjectProposals={fetchProjectProposals}
                  handleUpdateProposalStatus={handleUpdateProposalStatus}
                  index={index}
                />
              ))
            )}
          </div>
        )}

        {/* ✨ Submit Proposal Modal */}
        <AnimatePresence>
          {showModal && (
            <>
              {/* Backdrop */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowModal(false)}
                className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50"
              />

              {/* Modal */}
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="fixed inset-0 flex items-center justify-center p-4 z-50 pointer-events-none"
              >
                <div className="bg-white/95 backdrop-blur-xl rounded-2xl p-8 max-w-2xl w-full pointer-events-auto shadow-2xl max-h-[90vh] overflow-y-auto border border-white/20">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-bold bg-gradient-to-r from-shark-900 to-primary-600 bg-clip-text text-transparent">
                      Submit Proposal
                    </h2>
                    <button
                      onClick={() => setShowModal(false)}
                      className="p-2 hover:bg-shark-100 rounded-lg transition"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <form onSubmit={handleSubmitProposal} className="space-y-5">
                    <div>
                      <label className="block text-sm font-semibold text-shark-700 mb-2">
                        Select Project *
                      </label>
                      <select
                        required
                        value={formData.project_id}
                        onChange={(e) => setFormData({ ...formData, project_id: e.target.value })}
                        className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                      >
                        <option value="">Choose a project...</option>
                        {projects.map((project) => (
                          <option key={project.id} value={project.id}>
                            {project.title} (Budget: ${project.budget?.toLocaleString()})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-shark-700 mb-2">
                        Cover Letter *
                      </label>
                      <textarea
                        required
                        value={formData.cover_letter}
                        onChange={(e) => setFormData({ ...formData, cover_letter: e.target.value })}
                        placeholder="Explain why you're the best fit for this project..."
                        rows={6}
                        className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all resize-none"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-shark-700 mb-2">
                        Bid Amount ($) *
                      </label>
                      <input
                        type="number"
                        required
                        min="0"
                        step="0.01"
                        value={formData.bid_amount}
                        onChange={(e) => setFormData({ ...formData, bid_amount: e.target.value })}
                        placeholder="5000"
                        className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-shark-700 mb-2">
                        Timeline (days) *
                      </label>
                      <input
                        type="number"
                        required
                        min="1"
                        value={formData.timeline_days}
                        onChange={(e) => setFormData({ ...formData, timeline_days: e.target.value })}
                        placeholder="30"
                        className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                      />
                    </div>

                    {remainingSlots <= 1 && (
                      <div className="bg-amber-50/80 backdrop-blur-sm border border-amber-200/50 rounded-xl p-4">
                        <p className="text-sm text-amber-700">
                          ⚠️ This is your last available proposal slot. You can only have 3 pending proposals at a time.
                        </p>
                      </div>
                    )}

                    <div className="flex gap-3 pt-4">
                      <button
                        type="button"
                        onClick={() => setShowModal(false)}
                        className="flex-1 px-6 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 text-shark-700 rounded-xl hover:bg-white hover:shadow-md transition-all font-semibold"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="flex-1 px-6 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl hover:from-primary-600 hover:to-primary-700 transition-all shadow-lg hover:shadow-xl font-semibold"
                      >
                        Submit Proposal
                      </button>
                    </div>
                  </form>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

// ✨ Project Proposals Component (Client View)
const ProjectProposals = ({ project, fetchProjectProposals, handleUpdateProposalStatus, index }) => {
  const [proposals, setProposals] = useState([]);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (expanded) {
      loadProposals();
    }
  }, [expanded]);

  const loadProposals = async () => {
    setLoading(true);
    const data = await fetchProjectProposals(project.id);
    setProposals(data);
    setLoading(false);
  };

  const statusConfig = {
    open: { bg: 'from-green-500 to-green-600', text: 'Open', icon: '🟢' },
    in_progress: { bg: 'from-blue-500 to-blue-600', text: 'In Progress', icon: '🔵' },
    completed: { bg: 'from-gray-500 to-gray-600', text: 'Completed', icon: '⚪' },
    cancelled: { bg: 'from-red-500 to-red-600', text: 'Cancelled', icon: '🔴' },
  };

  const statusInfo = statusConfig[project.status] || statusConfig.open;
  const proposalCount = expanded ? proposals.length : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-xl border border-white/20 overflow-hidden"
    >
      {/* Project Header */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full p-6 text-left hover:bg-white/50 transition-colors"
      >
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <h3 className="text-xl font-bold text-shark-900 mb-3">{project.title}</h3>
            <div className="flex items-center gap-4 flex-wrap">
              <span className="text-sm text-shark-600">
                <span className="font-semibold">Budget:</span> ${project.budget?.toLocaleString()}
              </span>
              <span className={`px-3 py-1.5 bg-gradient-to-r ${statusInfo.bg} text-white rounded-full text-xs font-semibold shadow-md flex items-center gap-1`}>
                <span>{statusInfo.icon}</span>
                {statusInfo.text}
              </span>
              <span className="text-sm font-semibold text-primary-600">
                {expanded && !loading ? proposalCount : '...'} Proposal{proposalCount !== 1 ? 's' : ''}
              </span>
            </div>
          </div>
          <motion.div
            animate={{ rotate: expanded ? 180 : 0 }}
            transition={{ duration: 0.3 }}
            className="flex-shrink-0 ml-4"
          >
            <ChevronDown className="w-6 h-6 text-shark-400" />
          </motion.div>
        </div>
      </button>

      {/* Proposals List */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="p-6 pt-0 space-y-4 border-t border-shark-200/50">
              {loading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div>
                </div>
              ) : proposals.length === 0 ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mx-auto mb-3">
                    <FileText className="w-8 h-8 text-primary-600" />
                  </div>
                  <p className="text-shark-500">No proposals yet for this project</p>
                </div>
              ) : (
                proposals.map((proposal) => (
                  <div
                    key={proposal.id}
                    className="bg-white/50 backdrop-blur-sm rounded-xl p-4 space-y-3 border border-shark-100/50"
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-primary-400 to-primary-600 rounded-full flex items-center justify-center flex-shrink-0">
                          <User className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <Link 
                            to={`/profile/${proposal.freelancer.id}`}
                            className="font-bold text-shark-900 hover:text-primary-600 transition-colors cursor-pointer"
                          >
                            {proposal.freelancer?.name}
                          </Link>
                          <p className="text-sm text-shark-500">
                            ⭐ {proposal.freelancer?.average_rating?.toFixed(1) || '0.0'} • 
                            {proposal.freelancer?.total_projects_completed || 0} projects completed
                          </p>
                        </div>
                      </div>
                      <span className={`px-3 py-1.5 rounded-full text-xs font-semibold shadow-md ${
                        proposal.status === 'pending' ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-white' :
                        proposal.status === 'accepted' ? 'bg-gradient-to-r from-green-500 to-green-600 text-white' :
                        'bg-gradient-to-r from-red-500 to-red-600 text-white'
                      }`}>
                        {proposal.status}
                      </span>
                    </div>

                    <div className="flex gap-4 text-sm flex-wrap">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 bg-gradient-to-br from-green-400 to-green-600 rounded-lg flex items-center justify-center">
                          <DollarSign className="w-3 h-3 text-white" />
                        </div>
                        <span className="font-semibold text-shark-900">${proposal.bid_amount?.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center">
                          <Calendar className="w-3 h-3 text-white" />
                        </div>
                        <span className="text-shark-600">{proposal.timeline_days} days</span>
                      </div>
                    </div>

                    <div className="bg-white/80 backdrop-blur-sm rounded-lg p-3 border border-shark-100/50">
                      <p className="text-sm text-shark-700">{proposal.cover_letter}</p>
                    </div>

                    {proposal.status === 'pending' && (
                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={() => handleUpdateProposalStatus(proposal.id, 'accepted')}
                          className="flex-1 px-4 py-2.5 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl hover:from-green-600 hover:to-green-700 transition-all shadow-lg font-semibold"
                        >
                          Accept
                        </button>
                        <button
                          onClick={() => handleUpdateProposalStatus(proposal.id, 'rejected')}
                          className="flex-1 px-4 py-2.5 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-xl hover:from-red-600 hover:to-red-700 transition-all shadow-lg font-semibold"
                        >
                          Reject
                        </button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default Proposals;