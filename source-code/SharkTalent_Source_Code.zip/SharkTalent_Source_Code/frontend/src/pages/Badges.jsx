import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Award, Trophy, Star, CheckCircle, X, Clock } from 'lucide-react';
import { useAuthStore } from '../store/useStore';
import api from '../utils/api';
import toast from 'react-hot-toast';

const Badges = () => {
  const { user } = useAuthStore();
  const [badges, setBadges] = useState([]);
  const [quizzes, setQuizzes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedQuiz, setSelectedQuiz] = useState(null);
  const [quizQuestions, setQuizQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);
  const [quizResult, setQuizResult] = useState(null);
  const [takingQuiz, setTakingQuiz] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch user's badges
      const badgesResponse = await api.get(`/badges/user/${user.id}`);
      setBadges(badgesResponse.data.badges || []);
      
      // Fetch available quizzes
      const quizzesResponse = await api.get('/badges/quizzes');
      setQuizzes(quizzesResponse.data.quizzes || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load badges');
    } finally {
      setLoading(false);
    }
  };

  const startQuiz = async (quiz) => {
    try {
      const response = await api.get(`/badges/quiz/${quiz.id}`);
      setQuizQuestions(response.data.questions || []);
      setSelectedQuiz(quiz);
      setAnswers({});
      setShowResults(false);
      setQuizResult(null);
    } catch (error) {
      toast.error('Failed to load quiz');
    }
  };

  const handleAnswerSelect = (questionIndex, option) => {
    setAnswers({
      ...answers,
      [questionIndex]: option
    });
  };

  const submitQuiz = async () => {
    // Validate all questions answered
    if (Object.keys(answers).length !== quizQuestions.length) {
      toast.error('Please answer all questions');
      return;
    }

    try {
      setTakingQuiz(true);
      
      const response = await api.post('/badges/attempt', {
        quiz_id: selectedQuiz.id,
        answers: answers
      });

      setQuizResult(response.data);
      setShowResults(true);
      
      if (response.data.passed) {
        toast.success('Congratulations! You earned a badge! 🎉');
        fetchData(); // Refresh badges
      } else {
        toast.error('Quiz not passed. Try again!');
      }
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to submit quiz');
    } finally {
      setTakingQuiz(false);
    }
  };

  const closeQuiz = () => {
    setSelectedQuiz(null);
    setQuizQuestions([]);
    setAnswers({});
    setShowResults(false);
    setQuizResult(null);
  };

  const hasBadgeForSkill = (skillName) => {
    return badges.some(badge => badge.skill_name === skillName);
  };

  const getBadgeLevel = (level) => {
    const levels = {
      'verified': { color: 'bg-blue-100 text-blue-700', icon: '✓' },
      'expert': { color: 'bg-purple-100 text-purple-700', icon: '⭐' },
      'master': { color: 'bg-amber-100 text-amber-700', icon: '👑' }
    };
    return levels[level] || levels.verified;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (user.role !== 'freelancer') {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        <div className="text-center py-12 bg-white rounded-2xl shadow-sm border border-shark-200">
          <Award className="w-16 h-16 text-shark-300 mx-auto mb-4" />
          <p className="text-shark-500 text-lg">Badges are only available for freelancers</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-shark-900">Skill Badges</h1>
        <p className="text-shark-500 mt-2">Verify your skills by taking quizzes and earn badges</p>
      </div>

      {/* My Badges Section */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-shark-900 mb-4 flex items-center gap-2">
          <Trophy className="w-6 h-6 text-amber-500" />
          My Badges ({badges.length})
        </h2>
        
        {badges.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-sm border border-shark-200 p-8 text-center">
            <Award className="w-16 h-16 text-shark-300 mx-auto mb-4" />
            <p className="text-shark-500">No badges earned yet</p>
            <p className="text-sm text-shark-400 mt-2">Take quizzes below to earn your first badge!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {badges.map((badge) => {
              const levelInfo = getBadgeLevel(badge.badge_level);
              return (
                <motion.div
                  key={badge.id}
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="bg-white rounded-2xl shadow-sm border border-shark-200 p-6 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center">
                        <Award className="w-7 h-7 text-primary-600" />
                      </div>
                      <div>
                        <h3 className="font-bold text-shark-900">{badge.skill_name}</h3>
                        <span className={`text-xs px-2 py-1 rounded-full ${levelInfo.color} font-semibold`}>
                          {levelInfo.icon} {badge.badge_level}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  {badge.quiz_score && (
                    <div className="bg-shark-50 rounded-lg p-3 mb-3">
                      <p className="text-sm text-shark-600">
                        Quiz Score: <span className="font-bold text-primary-600">{badge.quiz_score}%</span>
                      </p>
                    </div>
                  )}
                  
                  <p className="text-xs text-shark-400">
                    Earned {new Date(badge.earned_at).toLocaleDateString()}
                  </p>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Available Quizzes Section */}
      <div>
        <h2 className="text-2xl font-bold text-shark-900 mb-4 flex items-center gap-2">
          <Star className="w-6 h-6 text-primary-600" />
          Available Quizzes
        </h2>
        
        {quizzes.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-sm border border-shark-200 p-8 text-center">
            <p className="text-shark-500">No quizzes available at the moment</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {quizzes.map((quiz) => {
              const hasSkillBadge = hasBadgeForSkill(quiz.skill_name);
              
              return (
                <motion.div
                  key={quiz.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`bg-white rounded-2xl shadow-sm border p-6 hover:shadow-md transition-all ${
                    hasSkillBadge ? 'border-green-200 bg-green-50' : 'border-shark-200'
                  }`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-bold text-shark-900 text-lg mb-1">{quiz.title}</h3>
                      <p className="text-sm text-primary-600 font-semibold">{quiz.skill_name}</p>
                    </div>
                    {hasSkillBadge && (
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    )}
                  </div>
                  
                  <p className="text-sm text-shark-600 mb-4 line-clamp-2">
                    {quiz.description || 'Test your knowledge and earn a badge'}
                  </p>
                  
                  <div className="flex items-center gap-2 text-sm text-shark-500 mb-4">
                    <Clock className="w-4 h-4" />
                    <span>Passing Score: {quiz.passing_score}%</span>
                  </div>
                  
                  <button
                    onClick={() => startQuiz(quiz)}
                    className={`w-full py-2 rounded-lg font-semibold transition ${
                      hasSkillBadge
                        ? 'bg-green-100 text-green-700 hover:bg-green-200'
                        : 'bg-primary-600 text-white hover:bg-primary-700'
                    }`}
                  >
                    {hasSkillBadge ? 'Retake Quiz' : 'Take Quiz'}
                  </button>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Quiz Modal */}
      <AnimatePresence>
        {selectedQuiz && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeQuiz}
              className="fixed inset-0 bg-black/30 backdrop-blur-sm z-50"
            />

            {/* Modal */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="fixed inset-0 flex items-center justify-center p-4 z-50 pointer-events-none"
            >
              <div className="bg-white rounded-2xl p-8 max-w-3xl w-full pointer-events-auto shadow-2xl max-h-[90vh] overflow-y-auto">
                {!showResults ? (
                  <>
                    {/* Quiz Header */}
                    <div className="flex justify-between items-start mb-6">
                      <div>
                        <h2 className="text-2xl font-bold text-shark-900">{selectedQuiz.title}</h2>
                        <p className="text-shark-500 mt-1">
                          {quizQuestions.length} questions • Passing score: {selectedQuiz.passing_score}%
                        </p>
                      </div>
                      <button
                        onClick={closeQuiz}
                        className="p-2 hover:bg-shark-100 rounded-lg transition"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    {/* Questions */}
                    <div className="space-y-6 mb-6">
                      {quizQuestions.map((q, index) => (
                        <div key={index} className="bg-shark-50 rounded-xl p-6">
                          <p className="font-semibold text-shark-900 mb-4">
                            {index + 1}. {q.question}
                          </p>
                          <div className="space-y-2">
                            {q.options.map((option, optIndex) => (
                              <button
                                key={optIndex}
                                onClick={() => handleAnswerSelect(index.toString(), option)}
                                className={`w-full text-left px-4 py-3 rounded-lg border-2 transition ${
                                  answers[index.toString()] === option
                                    ? 'border-primary-600 bg-primary-50 text-primary-900 font-semibold'
                                    : 'border-shark-200 bg-white hover:border-primary-300'
                                }`}
                              >
                                {option}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Progress */}
                    <div className="mb-6">
                      <div className="flex justify-between text-sm text-shark-600 mb-2">
                        <span>Progress</span>
                        <span>{Object.keys(answers).length} / {quizQuestions.length}</span>
                      </div>
                      <div className="w-full bg-shark-200 rounded-full h-2">
                        <div
                          className="bg-primary-600 h-2 rounded-full transition-all"
                          style={{ width: `${(Object.keys(answers).length / quizQuestions.length) * 100}%` }}
                        />
                      </div>
                    </div>

                    {/* Submit Button */}
                    <button
                      onClick={submitQuiz}
                      disabled={takingQuiz || Object.keys(answers).length !== quizQuestions.length}
                      className="w-full py-3 bg-primary-600 text-white rounded-xl font-semibold hover:bg-primary-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {takingQuiz ? 'Submitting...' : 'Submit Quiz'}
                    </button>
                  </>
                ) : (
                  <>
                    {/* Results */}
                    <div className="text-center">
                      <div className={`w-24 h-24 rounded-full mx-auto mb-6 flex items-center justify-center ${
                        quizResult.passed ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        {quizResult.passed ? (
                          <CheckCircle className="w-12 h-12 text-green-600" />
                        ) : (
                          <X className="w-12 h-12 text-red-600" />
                        )}
                      </div>

                      <h2 className="text-3xl font-bold text-shark-900 mb-2">
                        {quizResult.passed ? 'Congratulations!' : 'Not Quite There'}
                      </h2>
                      
                      <p className="text-shark-600 mb-6">
                        {quizResult.passed 
                          ? 'You passed the quiz and earned a badge!'
                          : 'Keep practicing and try again!'}
                      </p>

                      <div className="bg-shark-50 rounded-xl p-6 mb-6">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-shark-500 mb-1">Your Score</p>
                            <p className="text-3xl font-bold text-primary-600">{quizResult.score}%</p>
                          </div>
                          <div>
                            <p className="text-sm text-shark-500 mb-1">Correct Answers</p>
                            <p className="text-3xl font-bold text-shark-900">
                              {quizResult.correct_answers}/{quizResult.total_questions}
                            </p>
                          </div>
                        </div>
                      </div>

                      {quizResult.badge_earned && (
                        <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
                          <p className="text-green-700 font-semibold flex items-center justify-center gap-2">
                            <Award className="w-5 h-5" />
                            Badge Earned: {selectedQuiz.skill_name}
                          </p>
                        </div>
                      )}

                      <div className="flex gap-4">
                        <button
                          onClick={closeQuiz}
                          className="flex-1 px-6 py-3 border border-shark-300 text-shark-700 rounded-xl font-semibold hover:bg-shark-50 transition"
                        >
                          Close
                        </button>
                        {!quizResult.passed && (
                          <button
                            onClick={() => {
                              setShowResults(false);
                              setAnswers({});
                            }}
                            className="flex-1 px-6 py-3 bg-primary-600 text-white rounded-xl font-semibold hover:bg-primary-700 transition"
                          >
                            Try Again
                          </button>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Badges;