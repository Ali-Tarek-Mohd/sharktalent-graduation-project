import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  User, Mail, Briefcase, Star, Award, MapPin, Link as LinkIcon, 
  DollarSign, Calendar, MessageSquare 
} from 'lucide-react';
import api from '../utils/api';
import toast from 'react-hot-toast';

const Profile = () => {
  const { userId } = useParams();
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [badges, setBadges] = useState([]);
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    fetchProfile();
  }, [userId]);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      
      // Fetch user profile
      const profileRes = await api.get(`/auth/profile/${userId}`);
      setProfile(profileRes.data.user);

      // Fetch user reviews
      const reviewsRes = await api.get(`/reviews/user/${userId}`);
      setReviews(reviewsRes.data.reviews || []);

      // If freelancer, fetch badges
      if (profileRes.data.user.role === 'freelancer') {
        const badgesRes = await api.get(`/badges/user/${userId}`);
        setBadges(badgesRes.data.badges || []);
      }

      // Fetch user's projects (if client) or completed work (if freelancer)
      if (profileRes.data.user.role === 'client') {
        const projectsRes = await api.get(`/projects/?client_id=${userId}`);
        setProjects(projectsRes.data.projects?.slice(0, 5) || []);
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      toast.error('Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const renderStars = (rating) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-4 h-4 ${
              star <= Math.round(rating)
                ? 'fill-amber-400 text-amber-400'
                : 'fill-none text-gray-300'
            }`}
          />
        ))}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="p-6 max-w-5xl mx-auto text-center py-12">
        <User className="w-16 h-16 text-shark-300 mx-auto mb-4" />
        <p className="text-shark-500 text-lg">User not found</p>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header Card */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl shadow-sm border border-shark-200 p-8 mb-6"
      >
        <div className="flex items-start gap-6">
          {/* Avatar */}
          <div className="w-24 h-24 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0">
            <User className="w-12 h-12 text-primary-600" />
          </div>

          {/* Info */}
          <div className="flex-1">
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-3xl font-bold text-shark-900 mb-2">
                  {profile.first_name} {profile.last_name}
                </h1>
                <div className="flex items-center gap-3 text-shark-600 mb-4">
                  <span className="px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm font-semibold capitalize">
                    {profile.role}
                  </span>
                  {profile.average_rating > 0 && (
                    <div className="flex items-center gap-2">
                      <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
                      <span className="font-semibold">{profile.average_rating.toFixed(1)}</span>
                      <span className="text-sm text-shark-500">
                        ({reviews.length} review{reviews.length !== 1 ? 's' : ''})
                      </span>
                    </div>
                  )}
                </div>

                {profile.bio && (
                  <p className="text-shark-600 max-w-2xl">{profile.bio}</p>
                )}
              </div>

              <button className="px-6 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition font-semibold flex items-center gap-2">
                <MessageSquare className="w-4 h-4" />
                Contact
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-shark-200">
              <div>
                <p className="text-sm text-shark-500">Projects Completed</p>
                <p className="text-2xl font-bold text-shark-900">
                  {profile.total_projects_completed || 0}
                </p>
              </div>
              <div>
                <p className="text-sm text-shark-500">Member Since</p>
                <p className="text-2xl font-bold text-shark-900">
                  {new Date(profile.created_at).getFullYear()}
                </p>
              </div>
              {profile.role === 'freelancer' && (
                <div>
                  <p className="text-sm text-shark-500">Badges Earned</p>
                  <p className="text-2xl font-bold text-shark-900">{badges.length}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Details */}
        <div className="lg:col-span-1 space-y-6">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl shadow-sm border border-shark-200 p-6"
          >
            <h2 className="font-bold text-shark-900 mb-4">Contact Information</h2>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm">
                <Mail className="w-4 h-4 text-shark-400" />
                <span className="text-shark-600">{profile.email}</span>
              </div>
              {profile.location && (
                <div className="flex items-center gap-3 text-sm">
                  <MapPin className="w-4 h-4 text-shark-400" />
                  <span className="text-shark-600">{profile.location}</span>
                </div>
              )}
            </div>
          </motion.div>

          {/* Freelancer Details */}
          {profile.role === 'freelancer' && (
            <>
              {/* Skills */}
              {profile.skills && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  className="bg-white rounded-2xl shadow-sm border border-shark-200 p-6"
                >
                  <h2 className="font-bold text-shark-900 mb-4">Skills</h2>
                  <div className="flex flex-wrap gap-2">
                    {profile.skills.split(',').map((skill, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-blue-50 text-blue-700 rounded-lg text-sm font-medium"
                      >
                        {skill.trim()}
                      </span>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Hourly Rate */}
              {profile.hourly_rate && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 }}
                  className="bg-white rounded-2xl shadow-sm border border-shark-200 p-6"
                >
                  <h2 className="font-bold text-shark-900 mb-4">Hourly Rate</h2>
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-green-600" />
                    <span className="text-2xl font-bold text-shark-900">
                      ${profile.hourly_rate}
                    </span>
                    <span className="text-shark-500">/hour</span>
                  </div>
                </motion.div>
              )}

              {/* Portfolio */}
              {profile.portfolio_url && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 }}
                  className="bg-white rounded-2xl shadow-sm border border-shark-200 p-6"
                >
                  <h2 className="font-bold text-shark-900 mb-4">Portfolio</h2>
                  <a
                    href={profile.portfolio_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-primary-600 hover:text-primary-700 transition"
                  >
                    <LinkIcon className="w-4 h-4" />
                    View Portfolio
                  </a>
                </motion.div>
              )}

              {/* Badges */}
              {badges.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 }}
                  className="bg-white rounded-2xl shadow-sm border border-shark-200 p-6"
                >
                  <h2 className="font-bold text-shark-900 mb-4 flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-500" />
                    Badges
                  </h2>
                  <div className="space-y-2">
                    {badges.map((badge) => (
                      <div
                        key={badge.id}
                        className="flex items-center gap-2 p-2 bg-amber-50 rounded-lg"
                      >
                        <Award className="w-4 h-4 text-amber-600" />
                        <span className="text-sm font-medium text-shark-900">
                          {badge.skill_name}
                        </span>
                        <span className="text-xs text-amber-700 ml-auto capitalize">
                          {badge.badge_level}
                        </span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </>
          )}
        </div>

        {/* Right Column - Reviews & Projects */}
        <div className="lg:col-span-2 space-y-6">
          {/* Client Projects */}
          {profile.role === 'client' && projects.length > 0 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-2xl shadow-sm border border-shark-200 p-6"
            >
              <h2 className="font-bold text-shark-900 mb-4 flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-primary-600" />
                Recent Projects
              </h2>
              <div className="space-y-3">
                {projects.map((project) => (
                  <div
                    key={project.id}
                    className="p-4 bg-shark-50 rounded-lg hover:bg-shark-100 transition"
                  >
                    <p className="font-semibold text-shark-900">{project.title}</p>
                    <div className="flex items-center gap-4 mt-2 text-sm text-shark-600">
                      <span>Budget: ${project.budget?.toLocaleString()}</span>
                      <span className="capitalize">{project.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* Reviews */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-2xl shadow-sm border border-shark-200 p-6"
          >
            <h2 className="font-bold text-shark-900 mb-4 flex items-center gap-2">
              <Star className="w-5 h-5 text-amber-500" />
              Reviews ({reviews.length})
            </h2>
            
            {reviews.length === 0 ? (
              <p className="text-shark-500 text-center py-8">No reviews yet</p>
            ) : (
              <div className="space-y-4">
                {reviews.map((review) => (
                  <div key={review.id} className="p-4 bg-shark-50 rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-semibold text-shark-900">
                          {review.reviewer?.name || 'Client'}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          {renderStars(review.rating)}
                          <span className="text-sm text-shark-500">
                            {new Date(review.created_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                    {review.comment && (
                      <p className="text-sm text-shark-600 mt-2">{review.comment}</p>
                    )}
                    <p className="text-xs text-shark-400 mt-2">
                      Project: {review.project?.title}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Profile;