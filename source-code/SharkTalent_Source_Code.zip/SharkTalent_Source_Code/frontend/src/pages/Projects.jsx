import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Briefcase, Clock, DollarSign, MapPin, Edit2, Trash2, X, FileText, User } from 'lucide-react';
import { toast } from 'react-hot-toast';
import api from '../utils/api';
import { useAuthStore } from '../store/useStore';

const Projects = () => {
  const { user } = useAuthStore();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    budget: '',
    deadline: '',
    skills_required: '',
    category: 'Web Development',
  });

  const categories = [
    'Web Development',
    'Mobile Development',
    'Design',
    'Writing',
    'Marketing',
    'Data Science',
    'Other'
  ];

  const statusConfig = {
    open: { bg: 'from-green-500 to-green-600', text: 'Open', icon: '🟢' },
    in_progress: { bg: 'from-blue-500 to-blue-600', text: 'In Progress', icon: '🔵' },
    completed: { bg: 'from-gray-500 to-gray-600', text: 'Completed', icon: '⚪' },
    cancelled: { bg: 'from-red-500 to-red-600', text: 'Cancelled', icon: '🔴' },
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      setLoading(true);
      const endpoint = user?.role === 'client' ? '/projects/my-projects' : '/projects/';
      const response = await api.get(endpoint);
      setProjects(response.data.projects || response.data);
    } catch (error) {
      console.error('Error fetching projects:', error);
      toast.error('Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const projectData = {
        ...formData,
        budget: parseFloat(formData.budget),
        skills_required: formData.skills_required.split(',').map(s => s.trim()),
      };

      if (selectedProject) {
        await api.put(`/projects/${selectedProject.id}`, projectData);
        toast.success('Project updated successfully!');
      } else {
        await api.post('/projects/', projectData);
        toast.success('Project created successfully!');
      }
      
      setShowModal(false);
      resetForm();
      fetchProjects();
    } catch (error) {
      console.error('Error saving project:', error);
      toast.error(error.response?.data?.message || 'Failed to save project');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this project?')) return;
    
    try {
      await api.delete(`/projects/${id}`);
      toast.success('Project deleted successfully!');
      fetchProjects();
    } catch (error) {
      console.error('Error deleting project:', error);
      toast.error('Failed to delete project');
    }
  };

  const handleEdit = (project) => {
    setSelectedProject(project);
    setFormData({
      title: project.title,
      description: project.description,
      budget: project.budget,
      deadline: project.deadline?.split('T')[0] || '',
      skills_required: Array.isArray(project.skills_required) 
        ? project.skills_required.join(', ') 
        : project.skills_required || '',
      category: project.category || 'Web Development',
    });
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      budget: '',
      deadline: '',
      skills_required: '',
      category: 'Web Development',
    });
    setSelectedProject(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100">
      <div className="p-6 space-y-6">
        
        {/* ✨ Glass Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl px-6 py-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-shark-900 to-primary-600 bg-clip-text text-transparent">
                Projects
              </h1>
              <p className="text-sm text-shark-600 mt-1">
                {user?.role === 'client' ? 'Manage your posted projects' : 'Browse available projects'}
              </p>
            </div>
            {user?.role === 'client' && (
              <button
                onClick={() => {
                  resetForm();
                  setShowModal(true);
                }}
                className="px-6 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl hover:from-primary-600 hover:to-primary-700 transition-all shadow-lg hover:shadow-xl flex items-center gap-2 font-semibold"
              >
                <Plus className="w-5 h-5" />
                New Project
              </button>
            )}
          </div>
        </motion.div>

        {/* ✨ Projects Grid */}
        {projects.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-12 text-center"
          >
            <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mx-auto mb-4">
              <Briefcase className="w-10 h-10 text-primary-600" />
            </div>
            <h3 className="text-xl font-semibold text-shark-900 mb-2">No projects yet</h3>
            <p className="text-shark-500">
              {user?.role === 'client' 
                ? 'Create your first project to get started' 
                : 'Check back later for new opportunities'}
            </p>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project, index) => {
              const statusInfo = statusConfig[project.status] || statusConfig.open;
              
              return (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -4, scale: 1.02 }}
                  className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6 hover:shadow-2xl transition-all"
                >
                  {/* Project Header */}
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-lg font-bold text-shark-900 flex-1 line-clamp-2 pr-2">
                      {project.title}
                    </h3>
                    <span className={`px-3 py-1.5 bg-gradient-to-r ${statusInfo.bg} text-white rounded-full text-xs font-semibold shadow-md flex items-center gap-1 flex-shrink-0`}>
                      <span>{statusInfo.icon}</span>
                      {statusInfo.text}
                    </span>
                  </div>

                  {/* Description */}
                  <p className="text-shark-600 text-sm mb-4 line-clamp-3">
                    {project.description}
                  </p>

                  {/* Meta Info with Icons */}
                  <div className="space-y-2.5 mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-green-600 rounded-lg flex items-center justify-center flex-shrink-0">
                        <DollarSign className="w-4 h-4 text-white" />
                      </div>
                      <span className="font-semibold text-shark-900">${project.budget?.toLocaleString()}</span>
                    </div>
                    
                    {project.deadline && (
                      <div className="flex items-center gap-2 text-sm">
                        <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
                          <Clock className="w-4 h-4 text-white" />
                        </div>
                        <span className="text-shark-600">{new Date(project.deadline).toLocaleDateString()}</span>
                      </div>
                    )}
                    
                    {project.category && (
                      <div className="flex items-center gap-2 text-sm">
                        <div className="w-8 h-8 bg-gradient-to-br from-purple-400 to-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
                          <MapPin className="w-4 h-4 text-white" />
                        </div>
                        <span className="text-shark-600">{project.category}</span>
                      </div>
                    )}
                  </div>

                  {/* Skills */}
                  {project.skills_required && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {(Array.isArray(project.skills_required) 
                        ? project.skills_required 
                        : project.skills_required.split(',')
                      ).slice(0, 3).map((skill, i) => (
                        <span key={i} className="px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-xs font-medium">
                          {skill.trim()}
                        </span>
                      ))}
                      {(Array.isArray(project.skills_required) 
                        ? project.skills_required 
                        : project.skills_required.split(',')
                      ).length > 3 && (
                        <span className="px-3 py-1 bg-shark-100 text-shark-600 rounded-full text-xs font-medium">
                          +{(Array.isArray(project.skills_required) 
                            ? project.skills_required 
                            : project.skills_required.split(',')
                          ).length - 3} more
                        </span>
                      )}
                    </div>
                  )}

                  {/* Actions */}
                  {user?.role === 'client' && (
                    <div className="flex gap-2 pt-4 border-t border-shark-200/50">
                      <button
                        onClick={() => handleEdit(project)}
                        className="flex-1 px-4 py-2.5 bg-white/80 backdrop-blur-sm border border-shark-200/50 text-shark-700 rounded-xl hover:bg-white hover:shadow-md transition-all text-sm font-semibold flex items-center justify-center gap-2"
                      >
                        <Edit2 className="w-4 h-4" />
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(project.id)}
                        className="flex-1 px-4 py-2.5 bg-white/80 backdrop-blur-sm border border-red-200/50 text-red-600 rounded-xl hover:bg-red-50 hover:shadow-md transition-all text-sm font-semibold flex items-center justify-center gap-2"
                      >
                        <Trash2 className="w-4 h-4" />
                        Delete
                      </button>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        )}

        {/* ✨ Create/Edit Modal */}
        <AnimatePresence>
          {showModal && (
            <>
              {/* Backdrop */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => {
                  setShowModal(false);
                  resetForm();
                }}
                className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 z-50"
              />
              
              {/* Modal */}
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="fixed inset-0 flex items-center justify-center p-4 z-50 pointer-events-none"
              >
                <div className="bg-white/95 backdrop-blur-xl rounded-2xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto pointer-events-auto shadow-2xl border border-white/20">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold bg-gradient-to-r from-shark-900 to-primary-600 bg-clip-text text-transparent">
                      {selectedProject ? 'Edit Project' : 'Create New Project'}
                    </h2>
                    <button
                      onClick={() => {
                        setShowModal(false);
                        resetForm();
                      }}
                      className="p-2 hover:bg-shark-100 rounded-lg transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div>
                      <label className="block text-sm font-semibold text-shark-700 mb-2">
                        Project Title
                      </label>
                      <input
                        type="text"
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        required
                        placeholder="E.g., Build an E-commerce Website"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-shark-700 mb-2">
                        Description
                      </label>
                      <textarea
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all min-h-[120px]"
                        required
                        placeholder="Describe your project requirements..."
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-semibold text-shark-700 mb-2">
                          Budget ($)
                        </label>
                        <input
                          type="number"
                          value={formData.budget}
                          onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                          className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                          required
                          min="0"
                          step="0.01"
                          placeholder="1000"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-shark-700 mb-2">
                          Deadline
                        </label>
                        <input
                          type="date"
                          value={formData.deadline}
                          onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                          className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-shark-700 mb-2">
                        Category
                      </label>
                      <select
                        value={formData.category}
                        onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                        className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                      >
                        {categories.map((cat) => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-shark-700 mb-2">
                        Skills Required (comma-separated)
                      </label>
                      <input
                        type="text"
                        value={formData.skills_required}
                        onChange={(e) => setFormData({ ...formData, skills_required: e.target.value })}
                        className="w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                        placeholder="React, Node.js, MongoDB"
                      />
                    </div>

                    <div className="flex gap-3 pt-4">
                      <button
                        type="button"
                        onClick={() => {
                          setShowModal(false);
                          resetForm();
                        }}
                        className="flex-1 px-6 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 text-shark-700 rounded-xl hover:bg-white hover:shadow-md transition-all font-semibold"
                      >
                        Cancel
                      </button>
                      <button 
                        type="submit" 
                        className="flex-1 px-6 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl hover:from-primary-600 hover:to-primary-700 transition-all shadow-lg hover:shadow-xl font-semibold"
                      >
                        {selectedProject ? 'Update Project' : 'Create Project'}
                      </button>
                    </div>
                  </form>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Projects;