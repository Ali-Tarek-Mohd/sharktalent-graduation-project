import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Briefcase, FileText, MessageSquare, Award, TrendingUp, Clock, Star, Plus } from 'lucide-react';
import { useAuthStore } from '../store/useStore';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import toast from 'react-hot-toast';

const Dashboard = () => {
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState({
    projects: [],
    proposals: [],
    messages: [],
    badges: [],
    stats: {
      projectsCount: 0,
      proposalsCount: 0,
      messagesCount: 0,
      badgesCount: 0
    }
  });

  useEffect(() => {
    if (user && user.role) {
      fetchDashboardData();
    } else {
      setLoading(false);
    }
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      
      if (user.role === 'client') {
        const projectsRes = await api.get('/projects/my-projects');
        const projects = projectsRes.data.projects || [];
        
        setDashboardData({
          projects: projects.slice(0, 5),
          proposals: [],
          messages: [],
          badges: [],
          stats: {
            projectsCount: projects.length,
            proposalsCount: projects.reduce((acc, p) => acc + (p.proposal_count || 0), 0),
            messagesCount: 0,
            badgesCount: 0
          }
        });
      } else if (user.role === 'freelancer') {
        const proposalsRes = await api.get('/proposals/my-proposals');
        const proposals = proposalsRes.data.proposals || [];
        
        const badgesRes = await api.get(`/badges/user/${user.id}`);
        const badges = badgesRes.data.badges || [];
        
        setDashboardData({
          projects: [],
          proposals: proposals.slice(0, 5),
          messages: [],
          badges: badges,
          stats: {
            projectsCount: proposals.filter(p => p.status === 'accepted').length,
            proposalsCount: proposals.length,
            messagesCount: 0,
            badgesCount: badges.length
          }
        });
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const getProposalStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'bg-amber-100 text-amber-700';
      case 'accepted': return 'bg-green-100 text-green-700';
      case 'rejected': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-8 text-center"
        >
          <h2 className="text-2xl font-bold text-shark-900 mb-2">Authentication Required</h2>
          <p className="text-shark-600">Please log in to access your dashboard.</p>
        </motion.div>
      </div>
    );
  }

  const stats = user.role === 'client' ? [
    { 
      label: 'My Projects', 
      value: dashboardData.stats.projectsCount, 
      icon: Briefcase, 
      gradient: 'from-blue-500 to-blue-600',
      change: 'Total active' 
    },
    { 
      label: 'Total Proposals', 
      value: dashboardData.stats.proposalsCount, 
      icon: FileText, 
      gradient: 'from-green-500 to-green-600',
      change: 'Received' 
    },
    { 
      label: 'Messages', 
      value: dashboardData.stats.messagesCount, 
      icon: MessageSquare, 
      gradient: 'from-purple-500 to-purple-600',
      change: 'Coming soon' 
    },
    { 
      label: 'Completed', 
      value: user.total_projects_completed || 0, 
      icon: Award, 
      gradient: 'from-amber-500 to-amber-600',
      change: 'Projects done' 
    },
  ] : [
    { 
      label: 'Active Projects', 
      value: dashboardData.stats.projectsCount, 
      icon: Briefcase, 
      gradient: 'from-blue-500 to-blue-600',
      change: 'Accepted proposals' 
    },
    { 
      label: 'My Proposals', 
      value: dashboardData.stats.proposalsCount, 
      icon: FileText, 
      gradient: 'from-green-500 to-green-600',
      change: 'Total submitted' 
    },
    { 
      label: 'Messages', 
      value: dashboardData.stats.messagesCount, 
      icon: MessageSquare, 
      gradient: 'from-purple-500 to-purple-600',
      change: 'Coming soon' 
    },
    { 
      label: 'Badges', 
      value: dashboardData.stats.badgesCount, 
      icon: Award, 
      gradient: 'from-amber-500 to-amber-600',
      change: 'Skills verified' 
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100">
      <div className="p-6 space-y-6">
        
        {/* ✨ Glass Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl px-6 py-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-shark-900 to-primary-600 bg-clip-text text-transparent">
                Welcome back, {user?.first_name || 'User'}!
              </h1>
              <p className="text-sm text-shark-600 mt-1">
                {user.role === 'client' 
                  ? "Here's an overview of your projects and proposals."
                  : "Here's an overview of your proposals and badges."}
              </p>
            </div>
            <button
              onClick={() => navigate(user.role === 'client' ? '/projects' : '/projects')}
              className="px-6 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-xl hover:from-primary-600 hover:to-primary-700 transition-all shadow-lg hover:shadow-xl flex items-center gap-2 font-semibold"
            >
              <Plus className="w-5 h-5" />
              {user.role === 'client' ? 'New Project' : 'Browse Projects'}
            </button>
          </div>
        </motion.div>

        {/* ✨ Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * (index + 1) }}
                whileHover={{ y: -4, scale: 1.02 }}
                className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6 hover:shadow-2xl transition-all"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-shark-600 font-medium mb-1">{stat.label}</p>
                    <h3 className="text-3xl font-bold text-shark-900">{stat.value}</h3>
                    <p className="text-xs text-shark-500 mt-2">{stat.change}</p>
                  </div>
                  <div className={`w-12 h-12 bg-gradient-to-br ${stat.gradient} rounded-xl flex items-center justify-center shadow-lg`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* ✨ Recent Activity */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            className="lg:col-span-2 bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-shark-900">
                {user.role === 'client' ? 'Recent Projects' : 'Recent Proposals'}
              </h2>
              <Clock className="w-5 h-5 text-shark-400" />
            </div>
            
            <div className="space-y-3">
              {user.role === 'client' ? (
                dashboardData.projects.length === 0 ? (
                  <div className="text-center py-12">
                    <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Briefcase className="w-10 h-10 text-primary-600" />
                    </div>
                    <p className="text-shark-500 font-medium mb-2">No projects yet</p>
                    <p className="text-sm text-shark-400">Create your first project!</p>
                  </div>
                ) : (
                  dashboardData.projects.map((project, index) => (
                    <motion.div
                      key={project.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.6 + index * 0.1 }}
                      whileHover={{ scale: 1.01 }}
                      className="p-4 bg-white/50 backdrop-blur-sm rounded-xl border border-shark-100/50 hover:shadow-md transition-all cursor-pointer"
                      onClick={() => navigate(`/projects/${project.id}`)}
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-gradient-to-br from-primary-500 to-primary-600 rounded-full mt-2 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-shark-900 font-semibold truncate">{project.title}</p>
                          <p className="text-sm text-shark-600">Budget: ${project.budget?.toLocaleString()}</p>
                          <div className="flex items-center gap-2 mt-2 flex-wrap">
                            <span className="text-xs px-3 py-1 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-full font-semibold shadow-md">
                              {project.status}
                            </span>
                            {project.proposal_count > 0 && (
                              <span className="text-xs text-shark-500">
                                {project.proposal_count} proposal{project.proposal_count !== 1 ? 's' : ''}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))
                )
              ) : (
                dashboardData.proposals.length === 0 ? (
                  <div className="text-center py-12">
                    <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mx-auto mb-4">
                      <FileText className="w-10 h-10 text-primary-600" />
                    </div>
                    <p className="text-shark-500 font-medium mb-2">No proposals yet</p>
                    <p className="text-sm text-shark-400">Start applying to projects!</p>
                  </div>
                ) : (
                  dashboardData.proposals.map((proposal, index) => (
                    <motion.div
                      key={proposal.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.6 + index * 0.1 }}
                      whileHover={{ scale: 1.01 }}
                      className="p-4 bg-white/50 backdrop-blur-sm rounded-xl border border-shark-100/50 hover:shadow-md transition-all cursor-pointer"
                      onClick={() => navigate(`/proposals/${proposal.id}`)}
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-gradient-to-br from-primary-500 to-primary-600 rounded-full mt-2 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-shark-900 font-semibold truncate">{proposal.project?.title || 'Project'}</p>
                          <p className="text-sm text-shark-600">Bid: ${proposal.bid_amount?.toLocaleString()}</p>
                          <div className="flex items-center gap-2 mt-2 flex-wrap">
                            <span className={`text-xs px-3 py-1 rounded-full font-semibold shadow-md ${getProposalStatusColor(proposal.status)}`}>
                              {proposal.status}
                            </span>
                            <span className="text-xs text-shark-500">
                              {new Date(proposal.submitted_at).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))
                )
              )}
            </div>
          </motion.div>

          {/* ✨ Profile Stats */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <TrendingUp className="w-5 h-5 text-primary-600" />
              <h2 className="text-xl font-bold text-shark-900">Your Profile</h2>
            </div>
            
            <div className="space-y-4">
              <div className="text-center pb-4 border-b border-shark-200/50">
                <div className="w-20 h-20 bg-gradient-to-br from-primary-400 to-primary-600 rounded-full mx-auto mb-3 flex items-center justify-center shadow-lg">
                  <span className="text-3xl">
                    {user.role === 'client' ? '💼' : '👨‍💻'}
                  </span>
                </div>
                <p className="font-bold text-shark-900">{user.first_name} {user.last_name}</p>
                <p className="text-sm text-shark-600 capitalize">{user.role}</p>
                {user.average_rating > 0 && (
                  <div className="flex items-center justify-center gap-1 mt-2">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span className="font-semibold text-shark-900">{user.average_rating.toFixed(1)}</span>
                  </div>
                )}
              </div>

              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-shark-600">Profile Completion</span>
                  <span className="font-semibold text-shark-900">
                    {user.bio ? '80%' : '40%'}
                  </span>
                </div>
                <div className="w-full bg-shark-200/50 rounded-full h-2 overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: user.bio ? '80%' : '40%' }}
                    transition={{ duration: 1, delay: 0.7 }}
                    className="bg-gradient-to-r from-primary-500 to-primary-600 h-2 rounded-full shadow-sm"
                  />
                </div>
              </div>

              {user.role === 'freelancer' && dashboardData.badges.length > 0 && (
                <div>
                  <p className="text-sm font-semibold text-shark-700 mb-2">Badges Earned</p>
                  <div className="flex flex-wrap gap-2">
                    {dashboardData.badges.slice(0, 3).map((badge) => (
                      <span key={badge.id} className="text-xs px-3 py-1 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-full font-semibold shadow-md">
                        🏆 {badge.skill_name}
                      </span>
                    ))}
                    {dashboardData.badges.length > 3 && (
                      <span className="text-xs px-3 py-1 bg-white/80 backdrop-blur-sm text-shark-700 border border-shark-200/50 rounded-full font-medium">
                        +{dashboardData.badges.length - 3} more
                      </span>
                    )}
                  </div>
                </div>
              )}

              <div className="pt-4 border-t border-shark-200/50">
                <div className="flex justify-between text-sm">
                  <span className="text-shark-600">Projects Completed</span>
                  <span className="font-semibold text-shark-900">{user.total_projects_completed || 0}</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;