import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/useStore';
import Layout from './components/layout/Layout';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Projects from './pages/Projects';
import Proposals from './pages/Proposals';
import Messages from './pages/Messages';
import Milestones from './pages/Milestones';
import Reviews from './pages/Reviews';
import Badges from './pages/Badges';
import Settings from './pages/Settings';
import UserProfile from './pages/UserProfile';

// Protected Route Component - Blocks all access without authentication
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, user } = useAuthStore();
  
  // Check both token and user data
  const token = localStorage.getItem('token');
  
  // If no token OR not authenticated, redirect immediately
  if (!token || !isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  // Additional check: if token exists but no user data, redirect
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  return children;
};

// Public Route Component (redirect if already logged in)
const PublicRoute = ({ children }) => {
  const { isAuthenticated } = useAuthStore();
  return isAuthenticated ? <Navigate to="/dashboard" replace /> : children;
};

function App() {
  const { isAuthenticated } = useAuthStore();
  
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={
          <PublicRoute>
            <Login />
          </PublicRoute>
        } />
        <Route path="/register" element={
          <PublicRoute>
            <Register />
          </PublicRoute>
        } />

        {/* Protected Routes */}
        <Route path="/" element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="projects" element={<Projects />} />
          <Route path="proposals" element={<Proposals />} />
          <Route path="messages" element={<Messages />} />
          <Route path="milestones" element={<Milestones />} />
          <Route path="reviews" element={<Reviews />} />
          <Route path="badges" element={<Badges />} />
          <Route path="settings" element={<Settings />} />
          <Route path="profile/:userId" element={<UserProfile />} />
        </Route>

        {/* 404 Route - Check authentication first */}
        <Route path="*" element={
          isAuthenticated ? <Navigate to="/dashboard" replace /> : <Navigate to="/login" replace />
        } />
      </Routes>
    </BrowserRouter>
  );
}

export default App;