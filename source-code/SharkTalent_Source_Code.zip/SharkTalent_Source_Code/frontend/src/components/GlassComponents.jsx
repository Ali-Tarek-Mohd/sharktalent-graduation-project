import { motion } from 'framer-motion';
import { forwardRef } from 'react';

// ✨ Glass Card - Main container with glassmorphism effect
export const GlassCard = forwardRef(({ 
  children, 
  className = '', 
  hover = false,
  delay = 0,
  ...props 
}, ref) => {
  const Component = delay ? motion.div : 'div';
  
  const motionProps = delay ? {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { delay }
  } : {};

  return (
    <Component
      ref={ref}
      className={`bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl ${
        hover ? 'hover:shadow-2xl hover:scale-[1.02] transition-all duration-300' : ''
      } ${className}`}
      {...motionProps}
      {...props}
    >
      {children}
    </Component>
  );
});

GlassCard.displayName = 'GlassCard';

// ✨ Glass Header - Page header with glassmorphism
export const GlassHeader = ({ 
  title, 
  subtitle, 
  action, 
  className = '' 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-xl px-6 py-4 ${className}`}
    >
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-shark-900 to-primary-600 bg-clip-text text-transparent">
            {title}
          </h1>
          {subtitle && (
            <p className="text-sm text-shark-600 mt-1">{subtitle}</p>
          )}
        </div>
        {action && (
          <div>{action}</div>
        )}
      </div>
    </motion.div>
  );
};

// ✨ Glass Input - Input field with glassmorphism
export const GlassInput = forwardRef(({ 
  label, 
  error, 
  className = '',
  icon: Icon,
  ...props 
}, ref) => {
  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-sm font-medium text-shark-700">
          {label}
        </label>
      )}
      <div className="relative">
        {Icon && (
          <Icon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-shark-400 w-5 h-5" />
        )}
        <input
          ref={ref}
          className={`w-full px-4 py-3 bg-white/80 backdrop-blur-sm border border-shark-200/50 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent focus:bg-white transition-all shadow-sm ${
            Icon ? 'pl-10' : ''
          } ${error ? 'border-red-500' : ''} ${className}`}
          {...props}
        />
      </div>
      {error && (
        <p className="text-sm text-red-600">{error}</p>
      )}
    </div>
  );
});

GlassInput.displayName = 'GlassInput';

// ✨ Glass Button - Button with gradient
export const GlassButton = ({ 
  children, 
  variant = 'primary', 
  size = 'md',
  icon: Icon,
  className = '',
  ...props 
}) => {
  const variants = {
    primary: 'bg-gradient-to-r from-primary-500 to-primary-600 text-white hover:from-primary-600 hover:to-primary-700 shadow-lg hover:shadow-xl',
    secondary: 'bg-white/80 backdrop-blur-sm text-shark-900 border border-shark-200/50 hover:bg-white shadow-md hover:shadow-lg',
    danger: 'bg-gradient-to-r from-red-500 to-red-600 text-white hover:from-red-600 hover:to-red-700 shadow-lg hover:shadow-xl',
    ghost: 'bg-transparent text-shark-700 hover:bg-white/50'
  };

  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3',
    lg: 'px-8 py-4 text-lg'
  };

  return (
    <button
      className={`${variants[variant]} ${sizes[size]} rounded-xl font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 ${className}`}
      {...props}
    >
      {Icon && <Icon className="w-5 h-5" />}
      {children}
    </button>
  );
};

// ✨ Glass Badge - Badge with glassmorphism
export const GlassBadge = ({ 
  children, 
  variant = 'primary', 
  className = '' 
}) => {
  const variants = {
    primary: 'bg-gradient-to-r from-primary-500 to-primary-600 text-white',
    success: 'bg-gradient-to-r from-green-500 to-green-600 text-white',
    warning: 'bg-gradient-to-r from-yellow-500 to-yellow-600 text-white',
    danger: 'bg-gradient-to-r from-red-500 to-red-600 text-white',
    info: 'bg-gradient-to-r from-blue-500 to-blue-600 text-white',
    secondary: 'bg-white/80 backdrop-blur-sm text-shark-700 border border-shark-200/50'
  };

  return (
    <span className={`${variants[variant]} px-3 py-1 rounded-full text-xs font-semibold shadow-md ${className}`}>
      {children}
    </span>
  );
};

// ✨ Glass Avatar - Avatar with gradient background
export const GlassAvatar = ({ 
  name, 
  src, 
  size = 'md',
  className = '' 
}) => {
  const sizes = {
    sm: 'w-8 h-8 text-sm',
    md: 'w-10 h-10 text-base',
    lg: 'w-12 h-12 text-lg',
    xl: 'w-16 h-16 text-xl'
  };

  const initials = name
    ?.split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className={`${sizes[size]} rounded-full bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center text-white font-semibold shadow-lg ${className}`}>
      {src ? (
        <img src={src} alt={name} className="w-full h-full rounded-full object-cover" />
      ) : (
        <span>{initials}</span>
      )}
    </div>
  );
};

// ✨ Glass Container - Main page container with gradient background
export const GlassContainer = ({ 
  children, 
  className = '' 
}) => {
  return (
    <div className={`min-h-screen bg-gradient-to-br from-shark-50 via-primary-50/30 to-shark-100 ${className}`}>
      {children}
    </div>
  );
};

// ✨ Glass Grid - Grid layout with gap
export const GlassGrid = ({ 
  children, 
  cols = 3, 
  gap = 6, 
  className = '' 
}) => {
  const gridCols = {
    1: 'grid-cols-1',
    2: 'grid-cols-1 md:grid-cols-2',
    3: 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3',
    4: 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4'
  };

  return (
    <div className={`grid ${gridCols[cols]} gap-${gap} ${className}`}>
      {children}
    </div>
  );
};

// ✨ Glass Stats Card - Stats display
export const GlassStatsCard = ({ 
  title, 
  value, 
  icon: Icon, 
  trend, 
  trendUp = true,
  delay = 0 
}) => {
  return (
    <GlassCard hover delay={delay} className="p-6">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm text-shark-600 font-medium">{title}</p>
          <p className="text-3xl font-bold text-shark-900 mt-2">{value}</p>
          {trend && (
            <p className={`text-sm mt-2 ${trendUp ? 'text-green-600' : 'text-red-600'}`}>
              {trendUp ? '↑' : '↓'} {trend}
            </p>
          )}
        </div>
        {Icon && (
          <div className="w-12 h-12 bg-gradient-to-br from-primary-400 to-primary-600 rounded-xl flex items-center justify-center shadow-lg">
            <Icon className="w-6 h-6 text-white" />
          </div>
        )}
      </div>
    </GlassCard>
  );
};

// ✨ Glass Table - Table with glassmorphism
export const GlassTable = ({ 
  headers, 
  children, 
  className = '' 
}) => {
  return (
    <GlassCard className={`overflow-hidden ${className}`}>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gradient-to-r from-white/50 to-primary-50/30 border-b border-shark-200/50">
            <tr>
              {headers.map((header, index) => (
                <th
                  key={index}
                  className="px-6 py-4 text-left text-sm font-semibold text-shark-900"
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-shark-100/50">
            {children}
          </tbody>
        </table>
      </div>
    </GlassCard>
  );
};

// ✨ Glass Empty State - Empty state component
export const GlassEmptyState = ({ 
  icon: Icon, 
  title, 
  description, 
  action 
}) => {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      {Icon && (
        <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-primary-200 rounded-full flex items-center justify-center mb-4">
          <Icon className="w-10 h-10 text-primary-600" />
        </div>
      )}
      <h3 className="text-lg font-semibold text-shark-900 mb-2">{title}</h3>
      {description && (
        <p className="text-sm text-shark-500 mb-4 max-w-md">{description}</p>
      )}
      {action && <div>{action}</div>}
    </div>
  );
};

export default {
  GlassCard,
  GlassHeader,
  GlassInput,
  GlassButton,
  GlassBadge,
  GlassAvatar,
  GlassContainer,
  GlassGrid,
  GlassStatsCard,
  GlassTable,
  GlassEmptyState
};