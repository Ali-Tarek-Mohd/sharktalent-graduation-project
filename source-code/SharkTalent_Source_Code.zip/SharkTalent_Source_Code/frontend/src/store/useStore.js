import { create } from 'zustand';

export const useAuthStore = create((set) => ({
  user: JSON.parse(localStorage.getItem('user') || 'null'),
  token: localStorage.getItem('token'),
  isAuthenticated: !!localStorage.getItem('token') && !!localStorage.getItem('user'),
  
  setAuth: (user, token) => {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    set({ user, token, isAuthenticated: true });
  },
  
  logout: () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    set({ user: null, token: null, isAuthenticated: false });
    // Force redirect to login
    window.location.href = '/login';
  },
  
  updateUser: (userData) => {
    const updatedUser = { ...JSON.parse(localStorage.getItem('user') || '{}'), ...userData };
    localStorage.setItem('user', JSON.stringify(updatedUser));
    set((state) => ({ 
      user: { ...state.user, ...userData } 
    }));
  },
}));

export const useSidebarStore = create((set) => ({
  isCollapsed: false,
  toggleSidebar: () => set((state) => ({ isCollapsed: !state.isCollapsed })),
  setSidebar: (isCollapsed) => set({ isCollapsed }),
}));